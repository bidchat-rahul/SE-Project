<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('css/test.css');?>">
</head>
<body class="">
<h2>Start Page</h2>
<div><h6><?php echo anchor("site/loadLogin",$value='LogIn'); ?></h6></div>
<div><h6><?php echo anchor("site/loadBudgetAdd",$value='BudgetAdd'); ?></h6></div>
<div><h6><?php echo anchor("site/loadBudgetRecourds",$value='BudgetRecourds'); ?></h6></div>
<div><h6><?php echo anchor("site/loadCanSupply",$value='CanSupply'); ?></h6></div>
<!--<div><h6><?php // echo anchor("site/loadCategory",$value='Category'); ?></h6></div> -->
<div><h6><?php echo anchor("site/loadDefective",$value='Defective'); ?></h6></div>
<div><h6><?php echo anchor("site/loadItemPlace",$value='ItemPlace'); ?></h6></div>
<div><h6><?php echo anchor("site/loadItemAdd",$value='ItemAdd'); ?></h6></div>
<div><h6><?php echo anchor("site/loadMaintananceAdd",$value='MaintananceAdd'); ?></h6></div>
<div><h6><?php echo anchor("site/loadMaintananceByAdd",$value='MaintananceByAdd'); ?></h6></div>
<div><h6><?php echo anchor("site/loadPurchasesAdd",$value='PurchasesAdd'); ?></h6></div>
<div><h6><?php echo anchor("site/loadPurchasesUpdate",$value='PurchasesUpdate'); ?></h6></div>
<div><h6><?php echo anchor("site/loadRoomTypeAdd",$value='RoomTypeAdd'); ?></h6></div>
<div><h6><?php echo anchor("site/loadRoomTypeUpdate",$value='RoomTypeUpdate'); ?></h6></div>
<div><h6><?php echo anchor("site/loadSuppliersAdd",$value='SuppliersAdd'); ?></h6></div> 
<div><h6><?php echo anchor("site/loadSuppliersCategoryAdd",$value='SuppliersCategoryAdd');?></h6></div> 
<!-- <a href="<?php //echo base_url().'site/loadSuppliersCategoryAdd'?>">click me</a> -->
</body>
</html>
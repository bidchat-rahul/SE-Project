
<h2>insert Category</h2>
<?php echo form_open('site/test'); ?>
<div>
<label for="lblName">Name</label>
<input type="text" name="txtName" id="txtName"></input>
</div>
<div>
	<button>Submit</button>
</div>
<?php echo form_close();?>

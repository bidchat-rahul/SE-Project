<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sign Up Form</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/demo.css')?>">
        <link rel="stylesheet" href="<?php echo base_url('assets/demo1.css')?>">
    </head>
    <body>
<h2 style="text-align: center;">Update Room </h2>
<?php echo form_open('site/updateRoomData'); ?>
<div>
	<label for="cmbName">Name</label>
	<select name="sltName" id="sltName" required="true">
		<option value="">Please select a Room</option>
		<?php foreach($rooms->result() as $room){?>
		       <option value="<?php echo $room->id ?>"><?php echo $room->name; ?></option>
		   <?php } ?>
	</select>
</div>

<div>
	<label for="lblName">Name</label>
	<input type="text" name="txtName" id="txtName" value="" required="true"></input>
</div>

<div>
	<label for="lblCapacity">Capacity</label>
	<input type="number" name="txtCapacity" value="" id="txtCapacity" min="0" required="true"></input>
</div>

<div>
	<label for="lblDesc">Description</label>
	<textarea id="txtarDesc" name="txtarDesc" required="true"></textarea>
</div>

<div>
	<button>Submit</button>
</div>

<?php echo form_close(); ?>

<script type="text/javascript">
$("#sltName").change(function () {
	var id = $("#sltName").val();
	if (id!='') {
		$.ajax({
		    url : "<?php echo base_url('index.php/site/getDetails?id=') ?>" + id, 
		    type: "GET",
		    dataType: "JSON",
		    success: function(data)
		    {
		        $('[name="txtName"]').val(data.name);
		        $('[name="txtCapacity"]').val(data.capacity);
		        $('[name="txtarDesc"]').val(data.desc);
		    },
		    error: function (jqXHR, textStatus, errorThrown)
		    {
		        alert('Error get data from ajax');
		    }
		});
	};
});



</script>
</body>
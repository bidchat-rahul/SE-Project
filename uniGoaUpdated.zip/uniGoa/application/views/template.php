<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>UniGoa</title>
    
    <link href="<?php echo base_url('tempimport/css/simple-sidebar.css'); ?>" rel="stylesheet">
<script src="<?php echo base_url('tempimport/3.7.0/html5shiv.js');?>"></script>
<script src="<?php echo base_url('tempimport/1.4.2/respond.min.js');?>"></script>

<link href= <?php  echo base_url('importsFile/bootstrap/css/bootstrap.min.css') ?> rel="stylesheet"  type="text/css" >
<link href=<?php  echo base_url('importsFile/bootstrap-datepicker/css/bootstrap-datepicker3.min.css') ?> rel="stylesheet"  type="text/css" >

<script src=<?php echo base_url('importsFile/jquery/jquery-2.1.4.min.js') ?>></script>
<script src=<?php echo base_url('importsFile/bootstrap/js/bootstrap.min.js') ?> ></script>
<script src=<?php echo base_url('importsFile/bootstrap-datepicker/js/bootstrap-datepicker.min.js') ?>></script>

<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/log.css');?>">


</head>
<body>
<style type="text/css">
    ul
    {
        list-style-type: none;
    }
</style>
    <div id="wrapper">
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand">
                    <a href="#">
                        UniGoa Labs
                    </a>
                </li>

                 <li id="item"> <a href="#">Item</a></li>
                    <ul id="shItem" style="display: none;" >
                   <li> <?php echo anchor("site/loadItemAdd",$value='Add Item'); ?></li>
                   <li><?php echo anchor("site/loadItemPlaceUpdate",$value='Move Item'); ?></li>
                    <li>
                        <?php echo anchor("site/loadItemPlace",$value='Provide Place'); ?> 
                    </li>
                    </ul>

                    <li id="purchases"> <a href="#">Purchases Item</a></li>
                    <ul id="shPurchases" style="display: none;" >
                        <li>
                        <?php echo anchor("site/loadPurchasesAdd",$value='Add Purchases'); ?>
                        </li>

                        <li>
                        <?php echo anchor("site/loadPurchasesUpdate",$value='Provide Admin Id'); ?>
                        </li>
                    </ul>

<!--                 <li>
                    <?php // echo anchor("site/loadMaintananceAdd",$value='MaintananceAdd'); ?>
                </li>

                <li>
                    <?php // echo anchor("site/loadMaintananceByAdd",$value='MaintananceByAdd'); ?>
                    
                    
                </li> -->



 <!--                <li>
                <?php //echo anchor("site/loadRoomTypeAdd",$value='RoomTypeAdd'); ?>
                </li>

                <li>
                <?php // echo anchor("site/loadRoomTypeUpdate",$value='RoomTypeUpdate'); ?>
                </li> -->
<!-- 
                <li>
                <?php // echo anchor("site/loadSuppliersAdd",$value='SuppliersAdd'); ?> 
                </li>

                <li>
                  
                <?php // echo anchor("site/loadSuppliersCategoryAdd",$value='SuppliersCategoryAdd');?>  
                </li> -->

                 <li id="budget"> <a href="#">Budget</a></li>
                    <ul id="shBudget" style="display: none;" >
                       <li> <?php echo anchor("site/loadBudgetAdd",$value='Add Budget Head'); ?></li>
                       <li><?php echo anchor("site/loadBudgetRecourds",$value='Add Budget Records'); ?></li>
                    </ul>
                    
               
                <li id="supplier"><a href="#">Supplier</a> </li>
                    <ul id="shSupplier" style="display: none;" >
                       <li> <?php echo anchor("site/loadSuppliersAdd",$value='Add Supplier'); ?></li>
                       <li><?php echo anchor("site/loadSuppliersCategoryAdd",$value='Add Supplier Category'); ?></li>

                        <li>
                           <?php  echo anchor("site/loadCanSupply",$value='Can Supply'); ?> 
                        </li>
                    </ul>

                <li id="room"><a href="#">Room</a></li>
                    <ul id="shRoom" style="display: none;" >
                       <li> <?php echo anchor("site/loadRoomTypeAdd",$value='Add Room'); ?></li>
                       <li><?php echo anchor("site/loadRoomTypeUpdate",$value='Modify Room'); ?></li>
                    </ul>

<!--                 <li>
                <?php // echo anchor("site/getDefectiveList",$value='getDefectiveList'); ?>
                    
                </li> -->
                <li>
                <?php // echo anchor("site/getDefectiveListCat",$value='getDefectiveListCat'); ?>

                </li>
                <li>
                <?php echo anchor("site/getSuplierDataOnCondition",$value='get Product Supplier'); ?>

                </li>

                <li>
                <?php echo anchor("site/getRoomData",$value='get Room Data'); ?>

                </li>

              <li>
                <?php echo anchor("site/getBudgetRecoudsList",$value='get Budget On Year'); ?>
                </li> 
                <li>
                   <?php echo anchor("site/getListPurchases",$value='Get Purchases Details'); ?> 
                </li> 
                <li>
                <?php echo anchor("site/getSuplierData",$value='get Suppliers'); ?>                
                  
                </li>
                <li>
                    <?php echo form_open('site/logout'); ?>
                   <input type='Submit' class="btn btn-default" value='Logout' /> 
                    <?php echo form_close(); ?>
                </li>
            </ul>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <a href="#menu-toggle" class="btn btn-default" id="menu-toggle">Menu</a>
                </div> 
            </div>
        </div>

        <script type="text/javascript">
            
        $("#budget").click(function () {
            $("#shBudget").slideToggle('medium');
        });

        $("#supplier").click(function () {
            $("#shSupplier").slideToggle('medium');
        });

        $("#room").click(function () {
            $("#shRoom").slideToggle('medium');
        });

        $("#item").click(function () {
            $("#shItem").slideToggle('medium');
        });

        $("#purchases").click(function () {
            $("#shPurchases").slideToggle('medium');
        });
        </script>

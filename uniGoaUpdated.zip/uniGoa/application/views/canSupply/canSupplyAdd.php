<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sign Up Form</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/demo.css')?>">
        <link rel="stylesheet" href="<?php echo base_url('assets/demo1.css')?>">
</head>
<body>

<center><h2><font color="white">Supplier Details</font></h2></center>
<?php echo form_open('site/addCansupply'); ?>
<div>
<label for="lblSupCatId">Category :</label>
<select name="sltSupplierCatId" id="sltSupplierCatId" required="true">
<option value="" >Select</option>

	<?php foreach ($category as $value) { ?>

		<option value="<?php echo $value->id ?>" ><?php echo $value->name ?></option>

	<?php
	} ?>

</select>
</div><div>
<label for="lblSupplierId">Supplier :</label>
<select name="sltSupplierId" id="sltSupplierId" required="true">
<option value="" >Select</option>
	<?php foreach ($supplier as $value) { ?>

		<option value="<?php echo $value->id ?>" ><?php echo $value->name ?></option>

	<?php
	} ?>

</select>
</div>
<div>
	<button>Submit</button>
</div>
<?php echo form_close();?>

</body>

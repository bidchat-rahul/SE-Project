<head>
    <meta charset="UTF-8">
	<link rel="stylesheet" href="<?php echo base_url('assets/table.css')?>">  
				
</head>
<body>

<?php echo form_open('site/getBudgetRecoudsList'); ?>
<div style="text-align: center;">
	<label>Select Year</label>
	<select name="sltYear" required="true" onchange="this.form.submit();">
<option value="">Select</option>
	<?php foreach ($year as $value) { ?>
		
		<option value="<?php echo $value->year ?>" 
		<?php if ($value->year == $selectedYear ){
				echo "selected";

			} ?>
			


		><?php echo $value->year ?></option>

	<?php
	} ?>
	</select>
</div>

<?php if ($selectedYear != "") { ?>

	<h5 style="text-align: center;">Budget recourds for a year <?php echo $selectedYear ?> </h5>

	<table class="container">
		<thead>
			<tr>
				<th>Amt Provided</th>
				<th>Amt Spend </th>
				<th>Budget Remaining</th>
				<th>Budget Code</th>
				<th>Name</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($budgetRecords as $value) { ?>
			<tr>
				<td><?php echo $value->amtProvided ?></td>
				<td><?php echo $value->amtSpend ?></td>
				<td><?php $diff = $value->amtProvided - $value->amtSpend ; 
				echo $diff ?></td>
				<td><?php echo $value->budgetListId ?></td>
				<td><?php echo $value->name ?></td>
			</tr>
			<?php
			} ?>
		</tbody>

		
	</table>
<?php
} ?>

<?php echo form_close(); ?>
</body>
<head>
    <meta charset="UTF-8">
	<link rel="stylesheet" href="<?php echo base_url('assets/table.css')?>">  
				
</head>
<body>

<?php echo form_open('site/getListPurchases'); ?>
	<div  id="form" class="form-horizontal"  >
	    <div class="form-body">
	        <div class="form-group">
	            <label for="lblStartDate" class="control-label col-md-3" >From Period</label>
	            <div class="col-md-3">
	                <input name="dtpkrStartDate" placeholder="yyyy-mm-dd" class="form-control datepicker" required="true" type="text">
	            </div>
	        </div>
	    </div>
	</div>  

	<div  id="form" class="form-horizontal"  >
	    <div class="form-body">
	        <div class="form-group">
	            <label for="lblStartDate" class="control-label col-md-3" >To Period</label>
	            <div class="col-md-3">
	                <input name="dtpkrEndDate" placeholder="yyyy-mm-dd" class="form-control datepicker" required="true" type="text">
	            </div>
	        </div>
	    </div>
	</div>

	<button name="btnSubmit">Submit</button> 
	<?php echo form_close(); ?> 
<script type="text/javascript">

$(document).ready(function() {
    $('.datepicker').datepicker({
        autoclose: true,
        format: "yyyy-mm-dd",
        todayHighlight: true,
        orientation: "top left",
        todayBtn: true,
        todayHighlight: true,  
    });

});

</script> 
 
<?php if (($dates['startDate'] != "" && $dates['endDate'] != "") && (isset($purchases))) { ?>

<h5>purchases Details for a period from <?php echo $dates['startDate'] ?> to <?php echo $dates['endDate'] ?> </h5>
<table class="container">
	<thead>
		<tr>
			<th>Date Of Purchase</th>
			<th>Qty </th>
			<th>Total Amt (Tax Include)</th>
			<th>Budget Name</th>
			<th>Warranty Period</th>
			<th>File No</th>		
			<th>Item Name</th>
			<th>Brand Name</th>
			<th>Supplier Name</th>
						
		</tr>
	</thead>
	<tbody>
		<?php foreach ($purchases as $value) { ?>
		<tr>
			<td><?php echo $value->dateOfPurchase ?></td>
			<td><?php echo $value->qty ?></td>
			<td><?php echo $value->totalAmtIncludeTax ?></td>
			<td><?php echo $value->budgetName ?></td>

			<td><?php echo $value->warrantyPeriod ?></td>
			<td><?php echo $value->fileNo ?></td>
			<td><?php echo $value->itemName ?></td>
			<td><?php echo $value->brandName ?></td>
			<td><?php echo $value->supplierName ?></td>

		</tr>
		<?php
		} ?>
	</tbody>

	
</table>
<?php }  ?>

</body>
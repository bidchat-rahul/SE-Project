<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sign Up Form</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/demo.css')?>">
        <link rel="stylesheet" href="<?php echo base_url('assets/demo1.css')?>">
    </head>
    <body>
<form action="<?php echo base_url('index.php/site/loadPurchasesAdmin')."/".$updateFullData[0]->id;?>" method="post">

<div>
	<label for="lblDescOfItem">Desc Of Items</label>
	<textarea id="txtarDescOfItem" name="txtarDescOfItem" required="true">
		<?php echo $updateFullData[0]->descOfItem; ?>
	</textarea>
</div>

<div>
	<label for="lblWarrantyPeriod">Warenty period in months</label>
	<input type="number" id="txtWarrantyPeriod" name="txtWarrantyPeriod" value="<?php echo $updateFullData[0]->warrantyPeriod ?>" required="true"></input>
</div>

<div>
	<label for="lblQty">Qty</label>
	<input type="number" id="txtQty" name="txtQty" value="<?php  echo $updateFullData[0]->qty ?>" required="true"></input>
</div>

<div>
	<label for="lblUnitPrice">per Unit Price</label>
	<input type="number" id="txtUnitPrice" name="txtUnitPrice" value="<?php  echo $updateFullData[0]->unitPrice ?>"  step="0.01" required="true"></input>
</div>

<?php  $taxAmt = $updateFullData[0]->totalAmtIncludeTax - ($updateFullData[0]->unitPrice * $updateFullData[0]->qty)

?>
<div>
	<label for="lblTaxAmt">Tax Amt</label>
	<input type="number" id="txtTaxAmt" name="txtTaxAmt" step="0.01" value="<?php echo $taxAmt ?>"  required="true"></input>
	<!--total amt = (unitPrice*qty)+tax Amt -->
</div>

<div>
	<label for="lblSupplierId">Supplier name</label>
	<select id="sltSuppliers_name" name="sltSuppliers_name" required="true">
	<option value="">Please select</option>
	<?php foreach ($supplier as $value) { ?>


		<option value="<?php echo $value->id ?>"
		<?php
	        if ($value->id == $updateFullData[0]->supplierId) {
		        	echo "selected";}

		    ?> 

		 ><?php echo $value->name ?></option>

	<?php
	} ?>
	</select>
</div>

<div>
	<label for="lblBudgetHead">Budget Head</label>
	<select id="sltBudgetList_name" name="sltBudgetList_name" required="true">
	<option value="">Please select</option>
	<?php foreach ($budget as $value) { ?>

		<option value="<?php  echo $value->id ?>" 
		<?php
	        if ($value->id == $updateFullData[0]->budgetHead) {
		        	echo "selected";}

		    ?> 

		 > <?php echo $value->year ?> :<?php echo $value->name ?></option>

	<?php
	} ?>
	</select>
</div>


<div>
	<label for="lblFileNo">File No</label>
	<input type="text" id="txtFileNo" name="txtFileNo" value="<?php echo $updateFullData[0]->fileNo ?>"  required="true"></input>
</div>

<div>
	<label for="lblAdminNo">Admin Provided Id</label>
	<input type="text" id="txtAdminNo" name="txtAdminNo" value="" required="true"></input>
</div>

<div>
	<button formaction="<?php echo base_url('index.php/site/addPurchaseAdminId')."/".$updateFullData[0]->id;?>">Submit</button>
</div>
</form>
</body>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sign Up Form</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/demo.css')?>">
        <link rel="stylesheet" href="<?php echo base_url('assets/demo1.css')?>">
</head>
<body>
<h2>Insert Supplier Category</h2>
<?php echo form_open('site/addSuppliersCategory'); ?>
<div>
	<label for="lblName">Name</label>
	<input type="text" id="txtName" name="txtName" required="true"></input>
</div>
<div>
	<label for="lblRemark">Remark</label>
	<textarea id="txtarRemark" name="txtarRemark" ></textarea>
</div>

<div>
	<button>Submit</button>
</div>

<?php echo form_close(); ?>
</body>
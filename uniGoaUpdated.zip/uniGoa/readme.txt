software requirement 
Mysql Db
phpmyadmin 
local server
working  http://localhost/ link if
if you are on windows than you need to configure 
http://127.0.0.1/ in  your local host path 
/uniGoa/application/config/config.php 
set 
$config['base_url']	= 'http://127.0.0.1/uniGoa/';

databaseFile at 
/your LocalHost www Path /uniGoa/emptyDb/unigoaLabs.sql

in phpmyadmin
crate a DataBase 
than import dataBase file

configure your DataBase Name, Path, userName,passwd 
in 

/uniGoa/application/config/database.php 

and run in webUrl
http://127.0.0.1/uniGoa/

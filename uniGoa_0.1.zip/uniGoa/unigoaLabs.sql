-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u1build0.15.04.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 05, 2016 at 08:47 PM
-- Server version: 5.6.28-0ubuntu0.15.04.1
-- PHP Version: 5.6.4-4ubuntu6.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `unigoaLabs`
--

-- --------------------------------------------------------

--
-- Table structure for table `budgetList`
--

CREATE TABLE IF NOT EXISTS `budgetList` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='names of the budget heads are stored';

--
-- Dumping data for table `budgetList`
--

INSERT INTO `budgetList` (`id`, `name`, `desc`) VALUES
(80, 'Purchase', 'Purchases done thoug'),
(81, 'repair', 'paymet of repairs through');

-- --------------------------------------------------------

--
-- Table structure for table `budgetRecourds`
--

CREATE TABLE IF NOT EXISTS `budgetRecourds` (
`id` int(11) NOT NULL,
  `year` int(4) NOT NULL,
  `amtProvided` int(11) NOT NULL,
  `amtSpend` int(11) NOT NULL DEFAULT '0',
  `budgetListId` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COMMENT='bugetRecived all over the period and spending ';

--
-- Dumping data for table `budgetRecourds`
--

INSERT INTO `budgetRecourds` (`id`, `year`, `amtProvided`, `amtSpend`, `budgetListId`) VALUES
(2, 2000, 20000, 0, 80),
(3, 2016, 20000, 150730, 80),
(8, 2016, 234, 5010, 81),
(9, 2015, 1200000, 0, 80);

-- --------------------------------------------------------

--
-- Table structure for table `canSupply`
--

CREATE TABLE IF NOT EXISTS `canSupply` (
  `supplierId` int(11) NOT NULL,
  `supplierCatId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='transection table between supplier  and supplierCategory';

--
-- Dumping data for table `canSupply`
--

INSERT INTO `canSupply` (`supplierId`, `supplierCatId`) VALUES
(2, 1),
(1, 1),
(1, 2),
(7, 1),
(7, 2),
(8, 3),
(11, 10);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `name` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='item categorys of unigoa labs';

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`name`) VALUES
('a'),
('Acer'),
('Asus'),
('Bajaj'),
('Hitachi'),
('lenevo'),
('LG'),
('Sony');

-- --------------------------------------------------------

--
-- Table structure for table `defactive`
--

CREATE TABLE IF NOT EXISTS `defactive` (
`id` int(11) NOT NULL,
  `reason` text NOT NULL,
  `dateOfDefectFound` date NOT NULL,
  `itemPlaceId` int(11) NOT NULL,
  `isSolve` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COMMENT='stores reasons of defect in item';

--
-- Dumping data for table `defactive`
--

INSERT INTO `defactive` (`id`, `reason`, `dateOfDefectFound`, `itemPlaceId`, `isSolve`) VALUES
(1, 'not working', '2016-04-21', 1, 0),
(2, 'not well', '2016-04-27', 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `itemPlaced`
--

CREATE TABLE IF NOT EXISTS `itemPlaced` (
`id` int(11) NOT NULL,
  `subPlace` text NOT NULL,
  `deptNoProvided` text NOT NULL,
  `varification` varchar(60) NOT NULL DEFAULT 'notDone',
  `purchaseId` int(11) NOT NULL,
  `roomTypeId` int(11) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'working'
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COMMENT='stores the each item location in the room';

--
-- Dumping data for table `itemPlaced`
--

INSERT INTO `itemPlaced` (`id`, `subPlace`, `deptNoProvided`, `varification`, `purchaseId`, `roomTypeId`, `status`) VALUES
(1, '8', 'gu/dest/mca/pc/r4/f103/51/04', 'notDone', 1, 5, 'working'),
(3, '2', 'gu/dest/mca/pc/r4/f103/51/05', 'notDone', 1, 5, 'working'),
(4, '3', 'unigoa/123/987/2016/34', 'notDone', 1, 1, 'working'),
(5, '4', 'unigoa/123/987/2016/35', 'notDone', 1, 1, 'working'),
(9, '5', 'unigoa/123/987/2016/55', 'notDone', 5, 8, 'working'),
(10, '6', 'test/test/lake/good', 'notDone', 1, 8, 'working'),
(11, '5', 'test/test/2016/1', 'notDone', 1, 1, 'working'),
(12, '9', 'dect/uni/2016/345', 'notDone', 8, 11, 'working'),
(13, '4', 'dect/uni/2016/344', 'notDone', 8, 9, 'working'),
(14, '7', 'dect/uni/2016/348', 'notDone', 8, 11, 'working'),
(15, 'roof', 'unigoa/123/987/2016/fan/1', 'notDone', 11, 11, 'working'),
(16, 'roof', 'unigoa/123/987/2016/projector/1', 'notDone', 12, 1, 'working');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE IF NOT EXISTS `items` (
`serialNo` int(11) NOT NULL,
  `name` text NOT NULL,
  `remark` text,
  `categoryId` varchar(60) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1 COMMENT='stores the data of brand names of items';

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`serialNo`, `name`, `remark`, `categoryId`) VALUES
(3, 'Pc', 'good', 'Acer'),
(5, 'Laptop', 'avrage', 'LG'),
(6, 'AC', 'best', 'lenevo'),
(7, 'Laptop', 'Good', 'lenevo'),
(9, 'Printer', 'good', 'Sony'),
(10, 'Laptop', 'good', 'Sony'),
(11, 'Pc', 'best', 'Asus'),
(12, 'Fan', 'Super fast', 'Bajaj'),
(13, 'Projector', 'display unit', 'Hitachi');

-- --------------------------------------------------------

--
-- Table structure for table `maintanance`
--

CREATE TABLE IF NOT EXISTS `maintanance` (
`serialNo` int(11) NOT NULL,
  `amcStartDate` date NOT NULL,
  `amcEndDate` date NOT NULL,
  `remark` text NOT NULL,
  `conditions` text NOT NULL,
  `purchasesId` int(11) NOT NULL,
  `amt` int(11) NOT NULL,
  `budgetHead` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COMMENT='maintanance details are been stored';

--
-- Dumping data for table `maintanance`
--

INSERT INTO `maintanance` (`serialNo`, `amcStartDate`, `amcEndDate`, `remark`, `conditions`, `purchasesId`, `amt`, `budgetHead`) VALUES
(1, '2016-04-21', '2016-04-25', 'test', '3 con', 1, 45000, 2);

-- --------------------------------------------------------

--
-- Table structure for table `maintananceBy`
--

CREATE TABLE IF NOT EXISTS `maintananceBy` (
`id` int(11) NOT NULL,
  `amt` int(11) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `mentenanceId` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COMMENT='maintanance by whom details are been stored and the actual amt recieved by them';

--
-- Dumping data for table `maintananceBy`
--

INSERT INTO `maintananceBy` (`id`, `amt`, `supplierId`, `mentenanceId`) VALUES
(1, 24000, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE IF NOT EXISTS `purchases` (
`id` int(11) NOT NULL,
  `dateOfPurchase` date NOT NULL,
  `qty` int(11) NOT NULL,
  `unitPrice` int(11) NOT NULL,
  `totalAmtIncludeTax` int(11) NOT NULL,
  `adminBlockNo` text,
  `budgetHead` int(11) NOT NULL,
  `warrantyPeriod` int(11) NOT NULL,
  `descOfItem` text NOT NULL,
  `fileNo` int(11) NOT NULL,
  `supplierId` int(11) NOT NULL,
  `itemSerialNo` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 COMMENT='transection table between items and supplier';

--
-- Dumping data for table `purchases`
--

INSERT INTO `purchases` (`id`, `dateOfPurchase`, `qty`, `unitPrice`, `totalAmtIncludeTax`, `adminBlockNo`, `budgetHead`, `warrantyPeriod`, `descOfItem`, `fileNo`, `supplierId`, `itemSerialNo`) VALUES
(1, '2016-04-21', 50, 500, 10000, 'test/tht/ijj/unigoa/lab/345/2001/785', 2, 12, 'test cpu', 45, 1, 3),
(3, '2016-05-01', 3, 3, 11, NULL, 3, 23, 'test', 32, 1, 3),
(4, '2016-05-01', 1, 34, 379, 'unigoa/23/12/345/7', 3, 34, '		ter	', 100, 1, 5),
(5, '2016-05-02', 2, 55000, 113467, '134345', 3, 36, '		2GB memory	', 250, 3, 10),
(6, '2016-05-04', 2, 50000, 100200, NULL, 3, 36, '2GB Ram\n', 250, 1, 10),
(7, '2016-05-03', 1, 65000, 65200, 'unigoa/23/12/345/765', 3, 24, '		2Ton	', 231, 4, 6),
(8, '2016-05-05', 20, 15000, 300200, 'Un', 3, 36, '		2 GB ram	', 245, 1, 3),
(9, '2016-05-05', 3, 12000, 36233, NULL, 3, 12, '2 gb ram', 213, 2, 11),
(10, '2016-05-05', 2, 15000, 30300, NULL, 3, 12, '3 GB Ram', 234, 8, 5),
(11, '2016-05-05', 1, 5000, 5010, 'adminBlock/2016/fan/23', 8, 12, '		2500 RPM	', 1, 9, 12),
(12, '2016-05-05', 2, 60000, 120230, 'adminBlock/2016/projector/23', 3, 12, '		Full screen projecctor 3d	', 56, 1, 13);

-- --------------------------------------------------------

--
-- Table structure for table `roomType`
--

CREATE TABLE IF NOT EXISTS `roomType` (
`id` int(11) NOT NULL,
  `name` text NOT NULL,
  `capacity` int(11) NOT NULL,
  `desc` text
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COMMENT='room details are stored ';

--
-- Dumping data for table `roomType`
--

INSERT INTO `roomType` (`id`, `name`, `capacity`, `desc`) VALUES
(1, 'lab 4', 30, 'CGA lab'),
(5, 'Lab 2', 50, 'lab 2'),
(8, 'Lab 3', 44, 'lab 3 computers'),
(9, 'cabinet 12', 5, 'Sirs room1'),
(11, 'Lab 5', 20, 'good');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE IF NOT EXISTS `suppliers` (
`id` int(11) NOT NULL,
  `name` text NOT NULL,
  `address` text NOT NULL,
  `contactNo` bigint(12) NOT NULL,
  `email` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1 COMMENT='supplier info is keept';

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `name`, `address`, `contactNo`, `email`) VALUES
(1, 'HiTech Computers pvt ltd', 'Panaji - goa', 2147483647, 'hitech@gmail.com'),
(2, 'sigma computes pvt ltd', 'mapusa goa', 1234567890, 'sigma@gmail.com'),
(3, 'subo com ltd', 'panaji', 2147483647, 'subo@gmail.com'),
(4, 'siva ltd', 'panaji', 9876543210, 'siva@yahoo.com'),
(5, 'test', 'rahul addr\ntest numbers', 9876543210, 'test@test.com'),
(6, 'high', 'gfhg panaji', 7687987876, 'rrr@hhh.com'),
(7, 'inventrom', 'panaji', 1234567890, 'rea@sea.com'),
(8, 'goaukar traders ltd', 'panaji', 1234567890, 'rharmalkar28@gmail.com'),
(9, 'Maruti Sales', 'Panaji Goa', 9878675465, 'rharmalkar28@gmail.com'),
(11, 'Provin industries ltd', 'Margao', 9823456787, 'bijal@gmail.com'),
(13, 'Bijal Traders', 'Panaji', 9823475612, 'bijal@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `suppliersCategory`
--

CREATE TABLE IF NOT EXISTS `suppliersCategory` (
`id` int(11) NOT NULL,
  `name` text NOT NULL,
  `remark` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COMMENT='details of categorys that  suppliers can supply';

--
-- Dumping data for table `suppliersCategory`
--

INSERT INTO `suppliersCategory` (`id`, `name`, `remark`) VALUES
(1, 'Pc', 'Personal computer'),
(2, 'Laptop', 'need'),
(3, 'Printer', 'output device'),
(6, 'Projector', 'Display'),
(8, 'Screen', 'Diaplay'),
(10, 'Battries', 'Power supply');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`) VALUES
('labIn', 'labin'),
('labUser', 'labUser');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `budgetList`
--
ALTER TABLE `budgetList`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `budgetRecourds`
--
ALTER TABLE `budgetRecourds`
 ADD PRIMARY KEY (`id`), ADD KEY `budgetListId` (`budgetListId`);

--
-- Indexes for table `canSupply`
--
ALTER TABLE `canSupply`
 ADD KEY `supplierId` (`supplierId`), ADD KEY `supplierCatId` (`supplierCatId`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
 ADD PRIMARY KEY (`name`);

--
-- Indexes for table `defactive`
--
ALTER TABLE `defactive`
 ADD PRIMARY KEY (`id`), ADD KEY `itemPlaceId` (`itemPlaceId`);

--
-- Indexes for table `itemPlaced`
--
ALTER TABLE `itemPlaced`
 ADD PRIMARY KEY (`id`), ADD KEY `roomTypeId` (`roomTypeId`), ADD KEY `purchaseId` (`purchaseId`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
 ADD PRIMARY KEY (`serialNo`), ADD KEY `categoryId` (`categoryId`);

--
-- Indexes for table `maintanance`
--
ALTER TABLE `maintanance`
 ADD PRIMARY KEY (`serialNo`), ADD KEY `purchasesId` (`purchasesId`), ADD KEY `budgetHead` (`budgetHead`);

--
-- Indexes for table `maintananceBy`
--
ALTER TABLE `maintananceBy`
 ADD PRIMARY KEY (`id`), ADD KEY `supplierId` (`supplierId`), ADD KEY `mentenanceId` (`mentenanceId`);

--
-- Indexes for table `purchases`
--
ALTER TABLE `purchases`
 ADD PRIMARY KEY (`id`), ADD KEY `supplierId` (`supplierId`,`itemSerialNo`), ADD KEY `itemSerialNo` (`itemSerialNo`), ADD KEY `budgetHead` (`budgetHead`);

--
-- Indexes for table `roomType`
--
ALTER TABLE `roomType`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suppliersCategory`
--
ALTER TABLE `suppliersCategory`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `budgetRecourds`
--
ALTER TABLE `budgetRecourds`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `defactive`
--
ALTER TABLE `defactive`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `itemPlaced`
--
ALTER TABLE `itemPlaced`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
MODIFY `serialNo` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `maintanance`
--
ALTER TABLE `maintanance`
MODIFY `serialNo` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `maintananceBy`
--
ALTER TABLE `maintananceBy`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `purchases`
--
ALTER TABLE `purchases`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `roomType`
--
ALTER TABLE `roomType`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `suppliersCategory`
--
ALTER TABLE `suppliersCategory`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `budgetRecourds`
--
ALTER TABLE `budgetRecourds`
ADD CONSTRAINT `budgetList_budgetRec_fk` FOREIGN KEY (`budgetListId`) REFERENCES `budgetList` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `canSupply`
--
ALTER TABLE `canSupply`
ADD CONSTRAINT `supplierCategory_canSupply_fk` FOREIGN KEY (`supplierCatId`) REFERENCES `suppliersCategory` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `suppliers_canSupply_fk` FOREIGN KEY (`supplierId`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `defactive`
--
ALTER TABLE `defactive`
ADD CONSTRAINT `itemPlaced_defactive_fk` FOREIGN KEY (`itemPlaceId`) REFERENCES `itemPlaced` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `itemPlaced`
--
ALTER TABLE `itemPlaced`
ADD CONSTRAINT `purchases_itemPlaced_fk` FOREIGN KEY (`purchaseId`) REFERENCES `purchases` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `roomType_itemPlaced_fk` FOREIGN KEY (`roomTypeId`) REFERENCES `roomType` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `items`
--
ALTER TABLE `items`
ADD CONSTRAINT `category_item_fk` FOREIGN KEY (`categoryId`) REFERENCES `category` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `maintanance`
--
ALTER TABLE `maintanance`
ADD CONSTRAINT `budgetRecourds_maintainance_fk` FOREIGN KEY (`budgetHead`) REFERENCES `budgetRecourds` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `purchases_maintanance_fk` FOREIGN KEY (`purchasesId`) REFERENCES `purchases` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `maintananceBy`
--
ALTER TABLE `maintananceBy`
ADD CONSTRAINT `maintainance_mamtainanceby_fk` FOREIGN KEY (`mentenanceId`) REFERENCES `maintanance` (`serialNo`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `suppliers_mamtainanceby_fk` FOREIGN KEY (`supplierId`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `purchases`
--
ALTER TABLE `purchases`
ADD CONSTRAINT `budgetRecourds_purchases_fk` FOREIGN KEY (`budgetHead`) REFERENCES `budgetRecourds` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `items_purchases_fk` FOREIGN KEY (`itemSerialNo`) REFERENCES `items` (`serialNo`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `suppliers_purchases_fk` FOREIGN KEY (`supplierId`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

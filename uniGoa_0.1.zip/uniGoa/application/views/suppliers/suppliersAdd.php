<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sign Up Form</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/demo.css')?>">
        <link rel="stylesheet" href="<?php echo base_url('assets/demo1.css')?>">
    </head>
    <body>
<h2 style="text-align: center;">Insert Supplier</h2>
<?php echo form_open('site/addSuppliers'); ?>
<div>
	<label for="lblName">Name</label>
	<input type="text" id="txtName" name="txtName" required="true"></input>
</div>
<div>
	<label for="lblAddress">Address</label>
	<textarea id="txtarAddress" name="txtarAddress" required="true"></textarea>
</div>
<div>
	<label for="lblContactNo">Contact No</label>
	<input type="number" id="txtContactNo" name="txtContactNo" required="true"></input>
</div>
<div>
	<label for="lblEmail">Email</label>
	<input type="email" id="txtEmail" name="txtEmail" required="true"></input>
</div>
<div>
	<button>Submit</button>
</div>
<?php echo form_close(); ?>
</body>
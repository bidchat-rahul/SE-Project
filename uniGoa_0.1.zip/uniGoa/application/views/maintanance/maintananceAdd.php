<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="<?php echo base_url('assets/demo.css')?>">
        <link rel="stylesheet" href="<?php echo base_url('assets/demo1.css')?>">
    </head>
<body>

<h2>insert maintanance</h2>
<!--SerialNo :- autoIncrement
purchasesId :- inherit 
-->
<?php
		echo "Today is " . date("Y-m-d") . "<br>";
		$date1=date_create(date("Y-m-d"));
		$date2=date_create("2016-06-12");
		$diff=date_diff($date1,$date2);
		print_r($diff);
		echo "<br/>". $diff->days;

		$date=date_create("2013-03-15");
		date_add($date,date_interval_create_from_date_string("5 months"));
		echo "<br/>".date_format($date,"Y-m-d");


?>

<?php echo form_open('site/test'); ?>
<div>
	<label for="lblAmcStartDate">AMC Start Date</label>
	<!--Date Picker dtpkrAmcStartDate -->

		<div  id="form" class="form-horizontal"  >
	    <div class="form-body">
	        <div class="form-group">
	        <input name="dtpkrAmcStartDate" placeholder="yyyy-mm-dd" class="form-control datepicker" type="text" required="true">
<!-- 	            <div class="col-md-3">
	                
	            </div> -->
	        </div>
	    </div>
	</div> 
</div> 
<div>
	<label for="lblAmcEndDate">AMC End Date</label>
	<!--Date Picker dtpkrAmcEndDate -->

		<div  id="form" class="form-horizontal"  >
	    <div class="form-body">
	        <div class="form-group">
	        <input name="dtpkrAmcEndDate" placeholder="yyyy-mm-dd" class="form-control datepicker" type="text" required="true">
<!-- 	            <div class="col-md-3">
	                
	            </div> -->
	        </div>
	    </div>
	</div> 

	<!--<label for="lblPeriod">For the Period Of </label>
	<input type="number" id="txtPeriod" name="txtPeriod"></input>
	<select name="sltPeriodType">
		<option>Month</option>
		<option>Year</option>
	</select> -->
</div>
<div>
	<label for="lblAmt">Amount</label>
	<input type="number" id="txtAmt" name="txtAmt" step="0.01"></input>
	<!-- get double datatype numbers -->
</div>
<div>
	<label for="lblBudgetHead">Budget Head</label>
	<select id="sltBudgetList_name" name="sltBudgetList_name" required="true">
	<option value="">Please select</option>
	<?php foreach ($budget as $value) { ?>

		<option value="<?php echo $value->id ?>" > <?php echo $value->year ?> :<?php echo $value->name ?></option>

	<?php
	} ?>
	</select>
</div>
<div>
	<label for="lblConditions">Any Conditions</label>
	<textarea id="txtarCondition" name="txtarCondition"></textarea> 
</div>
<div>
	<label for="lblRemark">Remark</label>
	<textarea id="txtarRemark" name="txtarRemark"></textarea>
</div>

<div>
	<button>Submit</button>
</div> 
<?php echo form_close(); ?>

<script type="text/javascript">

$(document).ready(function() {
    $('.datepicker').datepicker({
        autoclose: true,
        format: "yyyy-mm-dd",
        todayHighlight: true,
        orientation: "top left",
        todayBtn: true,
        todayHighlight: true,  
    });

});

</script> 
</body>
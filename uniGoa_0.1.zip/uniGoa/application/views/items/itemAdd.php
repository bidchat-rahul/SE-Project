<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sign Up Form</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/demo.css')?>">
        <link rel="stylesheet" href="<?php echo base_url('assets/demo1.css')?>">
    </head>
    <body>
<center><h2><font color="white">Insert Item</font></h2></center>
<?php echo form_open('site/addItem'); ?>
<?php //echo form_open('site/test'); ?>
<div>
	<label for="lblCategoryId">Brand Name</label>
	<input list="sltCategory_name" id="lstCategoryName" name="lstCategoryName" required="true"></input>

	<datalist name="sltCategory_name" id="sltCategory_name" >
	
	<?php  foreach ($category as $value) { ?>

 		<option value="<?php echo $value->name ?>" ><?php echo $value->name ?></option> 

	<?php
	} ?>

	</datalist>
</div>

<div>
	<label for="lblName">Item Type</label>
	<input list="uniqueList" id="txtName" name="txtName" required="true"></input>
	  	<datalist id="uniqueList" name="uniqueList">
	  	
	  	<!-- fatch unique data from Item_name -->
		<?php foreach ($item as $value) { ?>

			<option value="<?php echo $value->name ?>" ><?php echo $value->name ?></option>

		<?php
		} ?>

		</datalist>
</div>

<div>
	<label for="lblRemark">Comment/Remark</label>
	<textarea id="txtarRemark" name="txtarRemark"></textarea>
</div>

<div>
	<button>Submit</button>
</div>


<?php echo form_close(); ?>
</body>
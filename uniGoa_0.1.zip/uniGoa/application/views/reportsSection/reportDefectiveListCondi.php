<div>
	<label>Select Item</label>
	<select name="sltSuppliersCategory">
	<?php foreach ($category as $value) { ?>

		<option value="<?php echo $value->name ?>" ><?php echo $value->name ?></option>

	<?php
	} ?>
	</select>
</div>

<h5>Defective <?php echo $itemName ?> Items </h5>

<table>
	<thead>
		<tr>
			<th>Item Name</th>	
			<th>Item Brand</th>
			<th>Reason of the Defect </th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($defectiveCat as $value) { ?>
		<tr>
			<td><?php echo $value->name ?></td>
			<td><?php echo $value->categoryId ?></td>
			<td><?php echo $value->reason ?></td>
		</tr>
		<?php
		} ?>
	</tbody>

	
</table>
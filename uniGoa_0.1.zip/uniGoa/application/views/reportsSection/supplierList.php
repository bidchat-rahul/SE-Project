<head>
    <meta charset="UTF-8">
		<title>Responsive</title>
	<link rel="stylesheet" href="<?php echo base_url('assets/table.css')?>">  
				
</head>
<body>
 
<h5 style="text-align: center;">Supplier Details</h5>

<?php if (!is_null($supplier)) { ?>

<table class="container">
	<thead>
		<tr>
			<th>Name</th>	
			<th>Address</th>
			<th>Contact No </th>
			<th>Email</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($supplier as $value) { ?>
		<tr>
			<td><?php echo $value->name ?></td>
			<td><?php echo $value->address ?></td>
			<td><?php echo $value->contactNo ?></td>
			<td><?php echo $value->email ?></td>
		</tr>
		<?php
		} ?>
	</tbody>

	
</table>
<?php }else{ ?>
	<h2>No Suppliers</h2>
<?php } ?>

<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title></title>
        <link rel="stylesheet" href="<?php echo base_url('assets/demo.css')?>">
        <link rel="stylesheet" href="<?php echo base_url('assets/demo1.css')?>">
    </head>
    <body>
<center><h2><font color="white">Move item from one place to another</font></h2></center>

<?php echo form_open('site/loadItemPlaceUpdate'); ?>
<div>
	<label for="cmbName">From Room</label>
	<select name="sltFromRoom" id="sltFromRoom" required="true" onchange="this.form.submit();">
		<option value="">Please select a Room</option>

		<?php foreach($rooms as $room){?>
		       <option value="<?php echo $room->id ?>"
 		       <?php

	        if ($room->id == $id) {
		        	echo "selected";}

		        ?> 
		       ><?php  echo $room->name; ?></option>
		   <?php } ?> 
	</select>
</div>


<div>
	<label for="lblItemName">Select Item Department Id </label>
	<select name="sltDeptId" id="sltDeptId" required="true"> 
		<option value="">Please select a Dept Id</option>

		<?php 
		foreach($itemId as $itemAd){?>

		<option value="<?php echo $itemAd->id ?>"><?php echo $itemAd->deptNoProvided; ?></option>

		<?php } ?>
	</select>
</div>

<div>
	<label for="cmbName">To Room</label>
	<select name="sltToRoom" id="sltToRoom" required="true">
		<option value="">Please select a Room</option>
		<?php foreach($rooms as $room){?>
		       <option value="<?php echo $room->id ?>"><?php echo $room->name; ?></option>
		   <?php } ?>
	</select>
</div>

<div>
	<label for="lblSubPlace">Sub Place</label>
	<input type="text" name="txtSubPlace" id="txtSubPlace" required="true"></input>
</div>



<div>
	<button type="submit" formaction="<?php echo base_url('index.php/site/updateMoveItem')?>">Submit</button>
</div>

<?php echo form_close(); ?>
</body>
<?php

class site extends CI_Controller{
	function test(){
		print_r($_POST);
		print_r($this->uri->segment(3));
		//print_r($this->uri->segment(4));
	}
	//Add Items
	function addItem(){

		$dataCategory = array(
			'name' => $this->input->post('lstCategoryName')
			);

		$data = array(
			'name' => $this->input->post('txtName'),
			'remark' => $this->input->post('txtarRemark'),
			'categoryId' => $dataCategory['name']
			);
		//if category_name not present in category then only insert in category :-done
		//insert only if category_name and item type not present in items msg alrady present :-done 
		//Check item type must be in Non-numeric
		$chkCat = $this->site_model->chkCategory($dataCategory['name']);

		if ($chkCat and $dataCategory['name'] != "" ) {
			$this->site_model->insertCategory($dataCategory);
		}

		$chkItm = $this->site_model->chkItem($data); 

		if ($chkItm and $data['name'] != "" and $data['categoryId'] != "" ) {
			$this->site_model->insertItems($data);
		}	

		$this->loadItemAdd();
	}

	//Add Suppliers
	function addSuppliers()
	{
		$data = array(
			'name' => $this->input->post('txtName'),
			'address' => $this->input->post('txtarAddress'),
			'contactNo' => $this->input->post('txtContactNo'),
			'email' => $this->input->post('txtEmail')
			);
		
		if($data['name'] != "") {
			$this->site_model->insertSuppliers($data);
		}

		$this->loadSuppliersAdd();
	}

	//Add Supplier category
	function addSuppliersCategory(){
		$data = array(
			'name' => $this->input->post('txtName'),
			'remark' => $this->input->post('txtarRemark')
			);
		$chk=$this->site_model->listSupliersCattegory1($data['name']);

		if (is_null($chk) && $data['name'] != "") {
			$this->site_model->insertSuppliersCategory($data);
		}
		$this->loadSuppliersCategoryAdd();

	}

	//Add can supply 
	function addCansupply(){
		$data = array(
			'supplierCatId' => $this->input->post('sltSupplierCatId'),
			'supplierId' => $this->input->post('sltSupplierId')
			);

		$test = $this->input->post('sltSupplierId');
		if ($test != "") {
			$chkCat = $this->site_model->chkCanSupply($data);
			
			if ($chkCat) {
				$this->site_model->insertCanSupply($data);
			}
		}

		$this->loadCanSupply();

	}

	// Add room Details
	function addRoom()
	{
		$values = array(
			'capacity' => $this->input->post('txtCapacity'),
			'desc' => $this->input->post('txtarDesc'),
			'name' => $this->input->post('txtName')
			);

		if ($values['name'] != "") {
			$chkRoom = $this->site_model->chkRoomType($values);

			if ($chkRoom) {
				$this->site_model->insertRoomType($values);
			}
		}

		$this->loadRoomTypeAdd();
	}

	function loadUpdateRoom()
	 {
	 	$id = $this->input->post('sltName');

	 	$showData = $this->site_model->getUpdateRoomData($id);
	 	$this->loadRoomTypeUpdate($showData);

	 } 
	 public function getDetails()
	{
		$this->db->select("*");
		$this->db->from("roomType");
		$this->db->where("id",$_GET['id']);
		$data=$this->db->get()->row();
		echo json_encode($data);
	}
	 function updateRoomData()
	 {

		$values = array(
			'id'=>$this->input->post('sltName'),
			'capacity' => $this->input->post('txtCapacity'),
			'desc' => $this->input->post('txtarDesc'),
			'name' => $this->input->post('txtName')
		);
		$this->site_model->updateRoomType($values);
		$this->loadRoomTypeUpdate();

	 }

	 //add budget list
	 function addBugetList(){
	 	$budget = array(
			'id' => $this->input->post('txtId'),
			'desc' => $this->input->post('txtDesc'),
			'name' => $this->input->post('txtName')
		);

		if ($budget['id'] != "") {
		 	$chkBudget = $this->site_model->chkBudgetList($budget);

		 	if ($chkBudget) {
				$this->site_model->insertBudgetList($budget);
			}
		}
	 	$this->loadBudgetAdd();
	 }
	 //add budget records
	 function addBudgetRecords(){
	 	$budget = array(
			'year' => $this->input->post('txtYear'),
			'budgetListId' => $this->input->post('sltBudgetListId'),
			'amtProvided' => $this->input->post('txtAmtProvided')
		);

		if ($budget['budgetListId'] != "") {
		 	$this->site_model->insertBudgetRecourds($budget);
		}

	 	$this->loadBudgetRecourds();

	 }
	 //add purchases
	 function addPurchases()
	 {

	 	$taxAmt = $this->input->post('txtTaxAmt');
	 	$qty = $this->input->post('txtQty');
	 	$unitPrice = $this->input->post('txtUnitPrice');

	 	$tempData = array(
			'name' => $this->input->post('sltItems_name'),
			'catId' => $this->input->post('sltCategory_name')
		);

	 	$itemSerialNo['number'] = $this->site_model->getItemSerialNo($tempData);
	 	$tempNo = $itemSerialNo['number'][0]->serialNo;

		$total_amt = ($unitPrice * $qty)+$taxAmt;
	 	$purchases = array(
			'dateOfPurchase' =>$this->input->post('dtpkrDateOfPurchase'),
			'qty' =>$qty,
			'unitPrice' =>$unitPrice,
			'totalAmtIncludeTax' =>$total_amt,
			'budgetHead' =>$this->input->post('sltBudgetList_name'),
			'warrantyPeriod' =>$this->input->post('txtWarrantyPeriod'),
			'descOfItem' =>$this->input->post('txtarDescOfItem'),
			'fileNo' =>$this->input->post('txtFileNo'),
			'supplierId' =>$this->input->post('sltSuppliers_name'),
			'itemSerialNo' =>$tempNo
		);
		$this->site_model->updateBudget($purchases['budgetHead'],$purchases['totalAmtIncludeTax']);
	 	$this->site_model->insertPurchases($purchases);
	 	$this->loadPurchasesAdd();
	 }

	 function addPurchaseAdminId()
	 {
	 	$t = $this->uri->segment(3);
	 	$taxAmt = $this->input->post('txtTaxAmt');
	 	$qty = $this->input->post('txtQty');
	 	$unitPrice = $this->input->post('txtUnitPrice');
	 	$total_amt = ($unitPrice * $qty)+$taxAmt;
	 	
	 	$tempData = array(
			'id' => $t,
			'qty' =>$qty,
			'unitPrice' =>$unitPrice,
			'totalAmtIncludeTax' =>$total_amt,
			'budgetHead' =>$this->input->post('sltBudgetList_name'),
			'warrantyPeriod' =>$this->input->post('txtWarrantyPeriod'),
			'descOfItem' =>$this->input->post('txtarDescOfItem'),
			'fileNo' =>$this->input->post('txtFileNo'),
			'supplierId' =>$this->input->post('sltSuppliers_name'),
			'adminBlockNo' => $this->input->post('txtAdminNo')
		);

	 	$test = $this->site_model->updatePurchases($tempData);
	 	$this->loadPurchasesUpdate();

	 }

	 function addItemPlace()
	 {
	 	$number = $this->input->post('boxNo');

	 	for ($i=0; $i < $number; $i++) { 

		 	$itemPlace = array(
				'roomTypeId' =>$this->input->post('roomTypeId'),
				'purchaseId' =>$this->input->post('purchaseId'),
				'subPlace' => $this->input->post('txtSubPlace'.$i),
				'deptNoProvided'=>$this->input->post('txtDeptNoProvided'.$i)
			);

			if ($itemPlace['subPlace'] != "" and $itemPlace['deptNoProvided'] != ""  ) {
				$add = $this->site_model->insertItemsPlace($itemPlace);
			}
	 	}
		$this->loadItemPlace();		
	 }

	 function updateMoveItem()
	 {
	 	$values = array(
			'subPlace' =>$this->input->post('txtSubPlace'),
			'roomTypeId' =>$this->input->post('sltToRoom'),
			'updateId' => $this->input->post('sltDeptId')
		);
	 	$this->site_model->updateItemPlace($values);
	 	$this->loadItemPlaceUpdate();
	 }

/*
Report Section
select data from defective items :done
*/
	 function getDefectiveList(){

	 	$data['defective'] = $this->site_model->defectiveList();
	 			 $this->load->view('template');
	 	$this->load->view('reportsSection/reportDefectiveItems',$data);
		 $this->load->view('template_footer');

	 }

	 function getDefectiveListCat(){ //done

	 	$data['itemName'] = 'Pc';
	 	$data['category'] = $this->site_model->listItem($data['itemName']);
	 	$data['defectiveCat'] = $this->site_model->defectiveCat($data['itemName']); //like Pc laptop other
	 	$this->load->view('template');
		$this->load->view('reportsSection/reportDefectiveListCondi',$data );
		$this->load->view('template_footer');
	 }

//done
	 function getSuplierDataOnCondition(){
	 	$data['itemName'] = 'laptop';
	 	$getId = $this->input->post('sltSuppliersCategory');

	 	if ($getId != "") {
			$data['itemName']= $getId;

		}
		$data['suppliersProduct'] = $this->site_model->supplierPerProduct( $data['itemName'] ); 

	 	$data['supplierCategory'] = $this->site_model->listSupliersCattegory();
	 	
	 	$this->load->view('template');
	 	$this->load->view('reportsSection/reportSuppliersWhoSupplies',$data );
	 	$this->load->view('template_footer');

	 }

	 function getRoomData(){ //done
	 	$data['roomName'] = 'Lab 3';
	 	
	 	$getId = $this->input->post('sltRoomName');

	 	if ($getId != "") {
			$data['roomName']= $getId;

		}
	 	$data['listRoom'] = $this->site_model->listRoom();
	 	$data['room'] = $this->site_model->itemInRoom($data['roomName']); 
	 	$this->load->view('template');
	 	$this->load->view('reportsSection/listRoomItem',$data );
	 	$this->load->view('template_footer');
	 }

	 function getMaintainerData(){
	 	$data['dates'] = array(
			'startDate' => '2016-04-2',
			'endDate' => '2016-04-30'
		);
	 	$data['maintainer'] = $this->site_model->listMaintenarName($data['dates']); //for a period of time

	 	$this->load->view('template');
	 	$this->load->view('reportsSection/reportMaintainarData',$data);
	 	$this->load->view('template_footer');
	 	
	 }

	 function getSuplierData() //done
	 {
	 	$data['supplier'] = $this->site_model->suplierList();
	 	$this->load->view('template');
	 	$this->load->view('reportsSection/supplierList',$data);
	 	$this->load->view('template_footer');
	 }

	function getListPurchases()
	{
		$startDate = $this->input->post('dtpkrStartDate');
		$endDate = $this->input->post('dtpkrEndDate');
		$data['dates'] = array(
			'startDate' => "",
			'endDate' => ""
		);
		$data['purchases']= "";

	 	if ($startDate != "" && $endDate != "" ) {
			$data['dates'] = array(
				'startDate' => $startDate,
				'endDate' => $endDate
			);
			$data['purchases'] = $this->site_model->listPurchases($data['dates']); 
			//for a period of time
		}
		$this->load->view('template');
	 	$this->load->view('reportsSection/reportPurchases',$data);
	 	$this->load->view('template_footer');		
	}

	function getBudgetRecoudsList()
	{
		$data['selectedYear'] = $this->input->post('sltYear');
		$data['year'] = $this->site_model->listBudgetRecourdsYear();
		$data['budgetRecords']="";

		if ($data['selectedYear'] != "") {
	
		$data['budgetRecords'] = $this->site_model->listBudgetRecourdsCondition($data['selectedYear']);
		}

		$this->load->view('template');
	 	$this->load->view('reportsSection/reportOnBudget',$data);
	 	$this->load->view('template_footer');
	}









	//Navigation Start from hear

	function loadStartPg(){
		$this->load->view('startPg');
	}

	function loadItemAdd(){
		
		$data['item']=$this->site_model->listItem1();
		$data['category']=$this->site_model->listCategary();

		$this->load->view('template');
		$this->load->view('items/itemAdd',$data);
		$this->load->view('template_footer');
	}
	function loadCategory(){ 		
		$this->load->view('template');
		$this->load->view('category/categoryAdd');
 		$this->load->view('template_footer');
	
	}

	function loadSuppliersAdd(){
 		$this->load->view('template');
		$this->load->view('suppliers/suppliersAdd');
 		$this->load->view('template_footer');		
	}


	function loadBudgetAdd(){
 		$this->load->view('template');
		$this->load->view('budgetList/budgetListAdd');
		$this->load->view('template_footer');
	}
	function loadBudgetRecourds(){

		$this->load->view('template');
		$data['budget']=$this->site_model->listBudgetList();
		$this->load->view('budgetRecourds/budgetRecourdsAdd',$data);
		$this->load->view('template_footer');
	}

	function loadCanSupply(){

		$data['supplier']=$this->site_model->listSupliers();
		$data['category']=$this->site_model->listSupliersCattegory();
		$data['listRoom'] = $this->site_model->listRoom();
		
		$this->load->view('template');
		$this->load->view('canSupply/canSupplyAdd',$data);
		$this->load->view('template_footer');
	}

	function loadDefective(){
		$data['item']=$this->site_model->listItem1();
		$data['category']=$this->site_model->listCategary();


		$this->load->view('template');
		$this->load->view('defactive/defactiveAdd');
		$this->load->view('template_footer');
	}

	function loadItemPlace(){
		$data['list'] = $this->site_model->listItemsNotAllocatedPlace();
		$data['listRoom'] = $this->site_model->listRoom();
		$this->load->view('template');
		$this->load->view('itemPlaced/itemPlacedAdd',$data);
		$this->load->view('template_footer');
	}

	function loadGenerateFilds()
	{

		$no['numberReq'] = $this->input->post('txtBoxNo');
		$no['roomTypeId'] = $this->input->post('sltRoomType_name');
		$no['purchaseId'] = $this->input->post('purchaseId');
		$this->load->view('template');
		$this->load->view('itemPlaced/generateFilds',$no);
		$this->load->view('template_footer');

	}	

	function loadMaintananceAdd(){
		$data['budget']=$this->site_model->listBudgetRecourds();

		$this->load->view('template');
		$this->load->view('maintanance/maintananceAdd',$data);
		$this->load->view('template_footer');
	}
	function loadMaintananceByAdd(){
		$this->load->view('template');
		$this->load->view('maintananceBy/maintananceByAdd');
		$this->load->view('template_footer');
	}
	function loadPurchasesAdd(){

		$data['supplier']=$this->site_model->listSupliers();
		$data['category']=$this->site_model->listCategary();
		$id = $this->input->post('sltCategory_name');
		$data['item'] = "";
		$data['id']="";
		if ($id != "") {
			$data['id']= $id;
			$data['item']=$this->site_model->listItem($id);
		}


		$data['budget']=$this->site_model->listBudgetRecourds();
		$this->load->view('template');
		$this->load->view('purchases/purchasesAdd',$data);
		$this->load->view('template_footer');
	}
	function loadPurchasesAdmin(){
		$key = $this->uri->segment(3);
		$data['supplier']=$this->site_model->listSupliers();
		$data['category']=$this->site_model->listCategary();
		$id = $this->input->post('sltCategory_name');
		$data['item'] = "";
		$data['id']="";
		if ($id != "") {
			$data['id']= $id;
			$data['item']=$this->site_model->listItem($id);
		}

		$data['budget']=$this->site_model->listBudgetRecourds();
		$data['updateFullData'] =$this->site_model->updateFullData($key);
		$this->load->view('template');
		$this->load->view('purchases/purchasesAdmin.php',$data);
		$this->load->view('template_footer');
	}
	function loadPurchasesUpdate(){

		$values['tableData']=$this->site_model->listPurchasesAdminIdRequerd();

		$this->load->view('template');
		$this->load->view('purchases/purchasesUpdateAdd',$values);
		$this->load->view('template_footer');
	}

	function loadRoomTypeAdd(){
		$this->load->view('template');
		$this->load->view('roomType/roomTypeAdd');
		$this->load->view('template_footer');
	}
	function loadRoomTypeUpdate()
	{
		//$data['rooms']=$this->site_model->listRoom();
		$this->db->select("id, name");
		$this->db->from("roomType");
		$data['rooms']=$this->db->get();

 		$this->load->view('template');
		$this->load->view('roomType/roomTypeUpdate',$data);
		$this->load->view('template_footer');
	}

	function loadSuppliersCategoryAdd(){
		$this->load->view('template');
		$this->load->view('suppliersCategory/suppliersCategoryAdd');
		$this->load->view('template_footer');
	}

	function loadItemPlaceUpdate()
	{
		$value['rooms'] = $this->site_model->listRoom();
		$id = $this->input->post('sltFromRoom');
		$value['itemId'] = "";
		$value['id'] = "";
		if ($id != "") {
			$value['id'] = $id ; 
			$value['itemId'] = $this->site_model->deptIdOnKey($id);
		}
		$this->load->view('template');
		$this->load->view('itemPlaced/itemPlaceUpdate',$value);
		$this->load->view('template_footer');
	}

	public function index()
	{

		if(!isset($this->session->userdata['logged_in'])){ 
		$this->load->view('login');
  		}
  		else{

			$data['supplier']=$this->site_model->listSupliers();
			$data['category']=$this->site_model->listCategary();
			$id = $this->input->post('sltCategory_name');
			$data['item'] = "";
			$data['id']="";
			if ($id != "") {
			  $data['item']=$this->site_model->listItem($id);
			}


			$data['budget']=$this->site_model->listBudgetRecourds();
			$this->load->view('template');
			$this->load->view('purchases/purchasesAdd',$data);
			$this->load->view('template_footer');

    	}
  	}

	public function logout()
	{
	$this->session->sess_destroy('logged_in');
	redirect('site/index','refresh');
	}


	public function login()
	{
	extract($_POST);

	$id = $this->site_model->check_login($username, $password);

	if(!$id)
	  {
	    redirect($this->load->view('login'));
	  }
	   else
	  {
	   redirect('site/index');
	  }
	}

} 

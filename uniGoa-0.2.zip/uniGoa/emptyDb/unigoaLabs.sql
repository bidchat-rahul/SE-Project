-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u1build0.15.04.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 11, 2016 at 10:52 PM
-- Server version: 5.6.28-0ubuntu0.15.04.1
-- PHP Version: 5.6.4-4ubuntu6.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `unigoaLabs`
--

-- --------------------------------------------------------

--
-- Table structure for table `budgetList`
--

CREATE TABLE IF NOT EXISTS `budgetList` (
  `name` varchar(50) NOT NULL,
  `descp` text NOT NULL,
  `reasons` text NOT NULL,
  `remarks` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='names of the budget heads are stored';

-- --------------------------------------------------------

--
-- Table structure for table `budgetRecourds`
--

CREATE TABLE IF NOT EXISTS `budgetRecourds` (
`id` int(11) NOT NULL,
  `year` int(4) NOT NULL,
  `amtProvided` int(11) NOT NULL,
  `amtSpend` int(11) NOT NULL DEFAULT '0',
  `budgetListId` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1 COMMENT='bugetRecived all over the period and spending ';

-- --------------------------------------------------------

--
-- Table structure for table `canSupply`
--

CREATE TABLE IF NOT EXISTS `canSupply` (
  `supplierId` int(11) NOT NULL,
  `supplierCatId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='transection table between supplier  and supplierCategory';

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `name` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='item categorys of unigoa labs';

-- --------------------------------------------------------

--
-- Table structure for table `defactive`
--

CREATE TABLE IF NOT EXISTS `defactive` (
`id` int(11) NOT NULL,
  `reason` text NOT NULL,
  `dateOfDefectFound` date NOT NULL,
  `itemPlaceId` int(11) NOT NULL,
  `isSolve` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='stores reasons of defect in item';

-- --------------------------------------------------------

--
-- Table structure for table `departmentIdsItems`
--

CREATE TABLE IF NOT EXISTS `departmentIdsItems` (
  `id` varchar(100) NOT NULL,
  `purchasesId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='details of Item Id  that Departments provides';

-- --------------------------------------------------------

--
-- Table structure for table `itemPlaced`
--

CREATE TABLE IF NOT EXISTS `itemPlaced` (
`id` int(11) NOT NULL,
  `subPlace` text NOT NULL,
  `deptNoProvided` varchar(100) NOT NULL,
  `varification` varchar(60) NOT NULL DEFAULT 'notDone',
  `roomTypeId` int(11) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'working'
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1 COMMENT='stores the each item location in the room';

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE IF NOT EXISTS `items` (
`serialNo` int(11) NOT NULL,
  `name` text NOT NULL,
  `remark` text,
  `categoryId` varchar(60) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1 COMMENT='stores the data of brand names of items';

-- --------------------------------------------------------

--
-- Table structure for table `maintanance`
--

CREATE TABLE IF NOT EXISTS `maintanance` (
`serialNo` int(11) NOT NULL,
  `amcStartDate` date NOT NULL,
  `amcEndDate` date NOT NULL,
  `remark` text,
  `conditions` text,
  `purchasesId` int(11) NOT NULL,
  `amt` int(11) NOT NULL,
  `budgetHead` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COMMENT='maintanance details are been stored';

-- --------------------------------------------------------

--
-- Table structure for table `maintananceBy`
--

CREATE TABLE IF NOT EXISTS `maintananceBy` (
`id` int(11) NOT NULL,
  `amt` int(11) DEFAULT NULL,
  `supplierId` int(11) NOT NULL,
  `mentenanceId` int(11) NOT NULL,
  `varify` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COMMENT='maintanance by whom details are been stored and the actual amt recieved by them';

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE IF NOT EXISTS `purchases` (
`id` int(11) NOT NULL,
  `dateOfPurchase` date NOT NULL,
  `qty` int(11) NOT NULL,
  `placeQty` int(11) NOT NULL DEFAULT '0',
  `removedQty` int(11) NOT NULL DEFAULT '0',
  `unitPrice` int(11) NOT NULL,
  `totalAmtIncludeTax` int(11) NOT NULL,
  `adminBlockNo` text,
  `budgetHead` int(11) NOT NULL,
  `warrantyPeriod` int(11) NOT NULL,
  `descOfItem` text NOT NULL,
  `fileNo` int(11) NOT NULL,
  `supplierId` int(11) NOT NULL,
  `itemSerialNo` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1 COMMENT='transection table between items and supplier';

-- --------------------------------------------------------

--
-- Table structure for table `roomType`
--

CREATE TABLE IF NOT EXISTS `roomType` (
`id` int(11) NOT NULL,
  `name` text NOT NULL,
  `capacity` int(11) NOT NULL,
  `desc` text
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COMMENT='room details are stored ';

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE IF NOT EXISTS `suppliers` (
`id` int(11) NOT NULL,
  `name` text NOT NULL,
  `address` text NOT NULL,
  `contactNo` bigint(12) NOT NULL,
  `contactName` varchar(100) NOT NULL,
  `email` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1 COMMENT='supplier info is keept';

-- --------------------------------------------------------

--
-- Table structure for table `suppliersCategory`
--

CREATE TABLE IF NOT EXISTS `suppliersCategory` (
`id` int(11) NOT NULL,
  `name` text NOT NULL,
  `remark` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1 COMMENT='details of categorys that  suppliers can supply';

-- --------------------------------------------------------

--
-- Stand-in structure for view `temp`
--
CREATE TABLE IF NOT EXISTS `temp` (
`allotedQty` bigint(21)
,`purchasesId` int(11)
);
-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure for view `temp`
--
DROP TABLE IF EXISTS `temp`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `temp` AS select count(`departmentIdsItems`.`id`) AS `allotedQty`,`departmentIdsItems`.`purchasesId` AS `purchasesId` from `departmentIdsItems` group by `departmentIdsItems`.`purchasesId`;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `budgetList`
--
ALTER TABLE `budgetList`
 ADD PRIMARY KEY (`name`);

--
-- Indexes for table `budgetRecourds`
--
ALTER TABLE `budgetRecourds`
 ADD PRIMARY KEY (`id`), ADD KEY `budgetListId` (`budgetListId`);

--
-- Indexes for table `canSupply`
--
ALTER TABLE `canSupply`
 ADD KEY `supplierId` (`supplierId`), ADD KEY `supplierCatId` (`supplierCatId`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
 ADD PRIMARY KEY (`name`);

--
-- Indexes for table `defactive`
--
ALTER TABLE `defactive`
 ADD PRIMARY KEY (`id`), ADD KEY `itemPlaceId` (`itemPlaceId`);

--
-- Indexes for table `departmentIdsItems`
--
ALTER TABLE `departmentIdsItems`
 ADD PRIMARY KEY (`id`), ADD KEY `purchasesId` (`purchasesId`);

--
-- Indexes for table `itemPlaced`
--
ALTER TABLE `itemPlaced`
 ADD PRIMARY KEY (`id`), ADD KEY `roomTypeId` (`roomTypeId`), ADD KEY `deptNoProvided` (`deptNoProvided`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
 ADD PRIMARY KEY (`serialNo`), ADD KEY `categoryId` (`categoryId`);

--
-- Indexes for table `maintanance`
--
ALTER TABLE `maintanance`
 ADD PRIMARY KEY (`serialNo`), ADD KEY `purchasesId` (`purchasesId`), ADD KEY `budgetHead` (`budgetHead`);

--
-- Indexes for table `maintananceBy`
--
ALTER TABLE `maintananceBy`
 ADD PRIMARY KEY (`id`), ADD KEY `supplierId` (`supplierId`), ADD KEY `mentenanceId` (`mentenanceId`);

--
-- Indexes for table `purchases`
--
ALTER TABLE `purchases`
 ADD PRIMARY KEY (`id`), ADD KEY `supplierId` (`supplierId`,`itemSerialNo`), ADD KEY `itemSerialNo` (`itemSerialNo`), ADD KEY `budgetHead` (`budgetHead`);

--
-- Indexes for table `roomType`
--
ALTER TABLE `roomType`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suppliersCategory`
--
ALTER TABLE `suppliersCategory`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `budgetRecourds`
--
ALTER TABLE `budgetRecourds`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `defactive`
--
ALTER TABLE `defactive`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `itemPlaced`
--
ALTER TABLE `itemPlaced`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
MODIFY `serialNo` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `maintanance`
--
ALTER TABLE `maintanance`
MODIFY `serialNo` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `maintananceBy`
--
ALTER TABLE `maintananceBy`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `purchases`
--
ALTER TABLE `purchases`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `roomType`
--
ALTER TABLE `roomType`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `suppliersCategory`
--
ALTER TABLE `suppliersCategory`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `budgetRecourds`
--
ALTER TABLE `budgetRecourds`
ADD CONSTRAINT `budgetList_budgetRec_fk` FOREIGN KEY (`budgetListId`) REFERENCES `budgetList` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `canSupply`
--
ALTER TABLE `canSupply`
ADD CONSTRAINT `supplierCategory_canSupply_fk` FOREIGN KEY (`supplierCatId`) REFERENCES `suppliersCategory` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `suppliers_canSupply_fk` FOREIGN KEY (`supplierId`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `defactive`
--
ALTER TABLE `defactive`
ADD CONSTRAINT `itemPlaced_defactive_fk` FOREIGN KEY (`itemPlaceId`) REFERENCES `itemPlaced` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `departmentIdsItems`
--
ALTER TABLE `departmentIdsItems`
ADD CONSTRAINT `purchases_deptId_fk` FOREIGN KEY (`purchasesId`) REFERENCES `purchases` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `itemPlaced`
--
ALTER TABLE `itemPlaced`
ADD CONSTRAINT `deptId_itemPlace_fk` FOREIGN KEY (`deptNoProvided`) REFERENCES `departmentIdsItems` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `roomType_itemPlaced_fk` FOREIGN KEY (`roomTypeId`) REFERENCES `roomType` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `items`
--
ALTER TABLE `items`
ADD CONSTRAINT `category_item_fk` FOREIGN KEY (`categoryId`) REFERENCES `category` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `maintanance`
--
ALTER TABLE `maintanance`
ADD CONSTRAINT `budgetRecourds_maintainance_fk` FOREIGN KEY (`budgetHead`) REFERENCES `budgetRecourds` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `purchases_maintanance_fk` FOREIGN KEY (`purchasesId`) REFERENCES `purchases` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `maintananceBy`
--
ALTER TABLE `maintananceBy`
ADD CONSTRAINT `maintainance_mamtainanceby_fk` FOREIGN KEY (`mentenanceId`) REFERENCES `maintanance` (`serialNo`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `suppliers_mamtainanceby_fk` FOREIGN KEY (`supplierId`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `purchases`
--
ALTER TABLE `purchases`
ADD CONSTRAINT `budgetRecourds_purchases_fk` FOREIGN KEY (`budgetHead`) REFERENCES `budgetRecourds` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `items_purchases_fk` FOREIGN KEY (`itemSerialNo`) REFERENCES `items` (`serialNo`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `suppliers_purchases_fk` FOREIGN KEY (`supplierId`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

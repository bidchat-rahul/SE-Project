<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="<?php echo base_url('assets/demo.css')?>">
        <link rel="stylesheet" href="<?php echo base_url('assets/demo1.css')?>">
    </head>
<body>
<h2>Complain for not working of item</h2>
<?php echo form_open('site/test'); ?>

<!-- dateOfDefectFound :- system date
	id :- auto increment
	isSolve :- default false
-->
<div>
<label for="lblCategary_name">Item Brand Name</label>
<select name="sltCategary_name" id="sltCategary_name">
	<option>Select</option>
</select>
</div><div>

<label for="lblItems_name">Item Name</label>
<select name="sltItems_name" id="Items_name">
	<option>Select</option>
</select>
</div><div>

<label for="lblRoomType_name">Place Name</label>
<select name="sltRoomType_name" id="sltRoomType_name">
	<option>Select</option>
</select>
</div><div>

<label for="lblItemPlaced_subPlace">Sub-place </label>
<select name="sltItemPlaced_subPlace" id="sltItemPlaced_subPlace">
	<option>Select</option>
</select>

<label for="lblItemPlaced_deptNoprovided">Dept Id</label>
<select name="lblItemPlaced_deptNoprovided" id="lblItemPlaced_deptNoprovided">
	<option>Select</option>
</select>

</div>
<!-- will be a list of recourds after selecting this -->
<!-- after selecting the item 
Query = Select itemPlaced.id ,items.name , category.name
from category,items,purchases,itemPlaced where status != Defective

added situation item can be moved from one place to another
afected table itemPlaced (subPlace,roomtypeId,varification=unvarified 
status)
-->
<div>
<label for="lblDefactive_reason">Defective Reason :</label>
<textarea name="txtarDefactive_reason" id="txtarDefactive_reason"></textarea>
</div>

<div>
	<button>Submit</button>
	<!--insert into defective values(sysdate(),id will be selected 
	value got from above query,txtarReason); -->
</div>

<!--as the item is defective it can be moved to another room
check box need to be provided if checked and submited redirect the page to 
MOVE_ITEM.php this will mostly be update query
 -->


<?php echo form_close(); ?>
</body>
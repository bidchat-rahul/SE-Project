<head>
    <meta charset="UTF-8">
		<title>Responsive</title>
	<link rel="stylesheet" href="<?php echo base_url('assets/table.css')?>">  
				
</head>
<body>
<?php echo form_open('site/getSuplierDataOnCondition'); ?>
<div style="text-align: center;">
	<label>Select Item</label>
	<select name="sltSuppliersCategory" required="true" onchange="this.form.submit();">
<option value="">Select</option>
	<?php foreach ($supplierCategory as $value) { ?>
		
		<option value="<?php echo $value->name ?>" 
		<?php if ($value->name == $itemName ){
				echo "selected";

			} ?>
			


		><?php echo $value->name ?></option>

	<?php
	} ?>
	</select>
</div>

<?php if (!is_null($suppliersProduct)) { 	?>


<h5 style="text-align: center;">Suppliers who can supply <?php echo $itemName ?> </h5>

<table class="container">
	<thead>
		<tr>
			<th>Supplier Name</th>
			<th>Address </th>
			<th>Contact No</th>
			<th>Email </th>
		</tr>
	</thead>
	<tbody>

		<?php foreach ($suppliersProduct as $value) { ?>
		<tr>
			<td><?php echo $value->sname ?></td>
			<td><?php echo $value->address ?></td>
			<td><?php echo $value->contactNo ?></td>
			<td><?php echo $value->email ?></td>
		</tr>
		<?php
		} ?>
	</tbody>

	
</table>
<?php } else{ ?>
	<h6>No One Supply This Item</h6>
<?php } ?>


<?php echo form_close(); ?>
</body>
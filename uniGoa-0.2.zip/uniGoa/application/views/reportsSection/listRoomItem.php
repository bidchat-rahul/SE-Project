<head>
    <meta charset="UTF-8">
		<title>Responsive</title>
	<link rel="stylesheet" href="<?php echo base_url('assets/table.css')?>">  
				
</head>
<body>
<?php echo form_open('site/getRoomData'); ?>
<div style="text-align: center;">
	<label>Select Room</label>
	<select name="sltRoomName" required="true" onchange="this.form.submit();">
	<option>Select</option>
	<?php foreach ($listRoom as $value) { ?>

		<option value="<?php echo $value->name?>" 
		<?php if ($value->name == $roomName ){
				echo "selected";

			} ?>
		><?php echo $value->name ?></option>

	<?php } ?>
	</select>
</div>
<h5 style="text-align: center;">List of Items In Room <?php echo $roomName ?> </h5>
<?php
if (!is_null($room)) { ?>
	
<table class="container">
	<thead>
		<tr>
			<th>Item Brand</th>
			<th>Item Name</th>	
			<th>Location Number </th>
			<th>Departmant No </th>
		</tr>
	</thead>

	<tbody>

<?php foreach ($room as $value) { ?>

		<tr>
			<td><?php echo $value->categoryId ?></td>
			<td><?php echo $value->name ?></td>
			<td><?php echo $value->subPlace ?></td>
			<td><?php echo $value->deptNo ?></td>
		</tr>
		<?php
		}   
		} else { ?>
			<td>No Records</td>
		<?php }	?>
	</tbody>

	
</table>
<?php echo form_close(); ?>
</body>
        
    </div>
    <!-- /#wrapper -->
    <!-- jQuery 
      <script src="http://localhost/uniGoa/tempimport/js/jquery.js"></script>
    <!-- Bootstrap Core JavaScript -->
      <script src="<?php //echo base_url('tempimport/js/bootstrap.min.js'); ?>"></script>
    <!-- Menu Toggle Script -->
    <script>
    $("#menu-toggle").click(function(e) {
       // e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    </script>
</body>
</html>
<head>
    <meta charset="UTF-8">
	<link rel="stylesheet" href="<?php echo base_url('assets/table.css')?>">  
</head>
<body>

<?php echo form_open('site/loadMaintainanceRenewRecords'); ?>
<div style="text-align: center;">
	<label>Enter days</label>
	<input type="number" name="txtDays" id="txtDays" value="" min="0" required="true"></input>
	<button>Submit</button>
</div>
<?php echo form_close(); ?>
<?php if (!is_null($tableData)) { ?>
 
<h2>Need to call for maintainance Renewal for the following items</h2>
<h2>upcoming maintainance Renewal for the next <?php echo $days; ?> days</h2>


<div>
<table class="container">
	<thead >
		<tr >
		
			<th>AMC End Date</th>
			<th>AMC Start Date</th>
			<th>Date Of Purchase</th>
			<th>Qty for maintainance</th>
			<th>Total Amt IncludeTax</th>
			<th>Budget Name</th>
			
			<th>File No</th>		
			<th>Item Name</th>
			<th>Brand Name</th>
			<th>Maintainnar Name</th>
			<th>Click</th>
		</tr>		
	</thead>
	<tbody  >
	<?php foreach ($tableData as $value) { ?>

		<tr>
			<td><?php echo $value->amcEndDate ?></td>
			<td><?php echo $value->amcStartDate ?></td>
			<td><?php echo $value->dateOfPurchase ?></td>
			<td><?php echo $value->qty ?></td>
			<td><?php echo $value->totalAmtIncludeTax ?></td>
			<td><?php echo $value->budgetName.": ".$value->budgetDescp ?></td>

			
			<td><?php echo $value->fileNo ?></td>
			<td><?php echo $value->itemName ?></td>
			<td><?php echo $value->brandName ?></td>
			<td><?php echo $value->supplierName ?></td> 
			<td><a href="<?php echo base_url('index.php/site/loadMaintananceUpdate') ?><?php echo '/'.$value->serialNo ?>" > Maintain Renewal </a></td>
		</tr>
	<?php
	} ?>
	</tbody>
</table>

<?php }else{ ?>

<h2>There are No items for maintanance Renewal in next <?php echo $days; ?> days </h2>

<?php } ?>
</body>
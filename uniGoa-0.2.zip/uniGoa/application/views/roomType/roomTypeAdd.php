<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sign Up Form</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/demo.css')?>">
        <link rel="stylesheet" href="<?php echo base_url('assets/demo1.css')?>">
    </head>
    <body>
<h2 style="text-align: center;">Insert RoomType</h2>
<?php echo form_open('site/addRoom'); ?>
<div>
	<label for="lblName">Name</label>
	<input type="text" name="txtName" id="txtName" required="true"></input>
</div>

<div>
	<label for="lblCapacity">Capacity</label>
	<input type="number" name="txtCapacity" id="txtCapacity" min="0" required="true"></input>
</div>

<div>
	<label for="lblDesc">Description</label>
	<textarea id="txtarDesc" name="txtarDesc" required="true"></textarea>
</div>

<div>
	<button>Submit</button>
</div>

<?php echo form_close(); ?>
</body>
<!DOCTYPE html>
<html>
<head>
	<title>veiw</title>
</head>
<body>

<p>this is my veiw</p>

</body>
</html>
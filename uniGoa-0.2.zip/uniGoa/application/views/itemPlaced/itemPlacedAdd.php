<head>
    <meta charset="UTF-8">
		<title>Responsive</title>
		<link rel="stylesheet" href="<?php echo base_url('css/test.css')?>"> 
		<link rel="stylesheet" href="<?php echo base_url('assets/table.css')?>">  
				
				
<style>
.button {
    background-color: 	#808080;
    border: none;
    color: 	white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}
</style>
</head>
<body>

<!--id :- autoIncreament
purchaseId :- inharitaded
varification :- notDone
status :- working
-->
<h2>Place the Item In a Room</h2>

<?php if (!is_null($list)) { 
$attributes = array('onsubmit' => 'return validate();');
	?>

<?php  echo form_open('site/loadGenerateFilds',$attributes); ?>
<table class="container">
	<thead>
<tr>
			<th>Date Of Purchase</th>
			<th>Qty</th>
			<th>Total Amt   (Including Tax)</th>
			<th>Budget Name</th>
			<th>Warranty Period</th>
			<th>File No</th>		
			<th>Item Name</th>
			<th>Brand Name</th>
			<th>Supplier Name</th>
			<th>Select</th>
		</tr>		
	</thead>
	<tbody>
	<?php

	$count = 1;

	 foreach ($list as $value) { ?>

		<tr>
			<td><?php echo $value->dateOfPurchase ?></td>
			<td id="<?php echo $count?>"><?php echo $value->qty ?></td>
			<td><?php echo $value->totalAmtIncludeTax ?></td>
			<td><?php echo $value->budgetName.": ". $value->budgetDescp ?></td>

			<td><?php echo $value->warrantyPeriod ?></td>
			<td><?php echo $value->fileNo ?></td>
			<td><?php echo $value->itemName ?></td>
			<td><?php echo $value->brandName ?></td>
			<td><?php echo $value->supplierName ?></td>
<td><input type="radio" name="purchaseId" required="true" onclick="test(<?php echo $count?>);" value="<?php echo $value->pid ?>" ></input></td>
		</tr>
	<?php
	$count++;	} ?>
	</tbody>
</table>

<div><br/><br/>
	<label for="lblRoomTypeId">Room Name</label>
	<select name="sltRoomType_name" id="sltRoomType_name" required="true">
	<option value="">Select</option>

	<?php foreach ($listRoom as $value) { ?>
		<option value="<?php echo $value->id ?>" ><?php echo $value->name ?></option>
	<?php
	} ?>
	</select>

	<label for="lblRoomTypeId">Number of items to be placed</label>
	<input type="number" name="txtBoxNo" id="txtBoxNo" required="true" min="1"></input>



	<label for="lblMsg" id="lblMsg" class="notice"></label>
<br/>
	<button class="button">Next</button>

</div>



<?php echo form_close();?>


<?php }else{ ?>

<h2>No Items To Place In Room</h2>

<?php	}  ?>

<script type="text/javascript">
var qty;

	function test(t) {
		qty = document.getElementById(t).innerHTML ;
	}
	function validate(){
		var test;
		test =  document.getElementById("txtBoxNo").value ;
		if (test <= qty) {
			return true;
		}
		document.getElementById('lblMsg').innerHTML = "Number Must be less then equal to Qty remainning";
		return false;
	}
</script>

</body>
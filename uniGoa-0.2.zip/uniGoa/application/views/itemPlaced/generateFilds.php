<head>
    <meta charset="UTF-8">
		<title> </title>
				<link rel="stylesheet" href="<?php echo base_url('assets/table.css')?>">  
</head>
<body>
<style type="text/css">
	.test{
		display: none;
	}
</style>
<?php
echo form_open('site/addItemPlace'); 

if (!is_null($deptId[0])) { 
if (count($deptId) <= $numberReq) {
	$numberReq = count($deptId);
}

echo form_hidden('purchaseId', $purchaseId);
echo form_hidden('roomTypeId', $roomTypeId);
echo form_hidden('boxNo', $numberReq);


for ($i=0; $i < $numberReq; $i++){ ?>

<div>
	<label for="lblSubPlace">Sub Place</label>
	<input list="sltSubPlace" required="true" name="txtSubPlace<?php echo $i?>" id="txtSubPlace<?php echo $i?>"  ></input>
	<datalist name="sltSubPlace" id="sltSubPlace" >
	
	<?php  foreach ($subPlace as $value) { ?>

 		<option value="<?php echo $value->subPlace ?>" ><?php echo $value->subPlace ?></option> 

	<?php
	} ?>

	</datalist>



	<label for="lblDeptNoProvided">Department No Provided</label>
	<select  name="sltDeptNoProvided<?php echo $i?>" id="sltDeptNoProvided<?php echo $i?>" required="true" onchange="test1(<?php echo $i?>,<?php echo $numberReq?>);">

	<option value="">Select</option>
	<?php foreach ($deptId as $value) { ?>
	<option value="<?php echo $value->id?>"><?php echo $value->id?></option>
	<?php } ?>
	</select> 

</div>

	<?php	} ?>
<div>
	<button>Submit</button>
</div>

<?php } else { ?>
	<h2>There is No Dept Id Provided to This Purchases</h2>
<?php } ?>

<?php echo form_close();?>

<script type="text/javascript">
var indexSelected = [];
	function test1() {
		
		var select1 ;
		var cur = arguments[0];
		select1 = document.getElementById("sltDeptNoProvided"+cur);
		var optionNo = select1.length ;
		indexSelected[cur]= select1.selectedIndex;

		for (var i = 0; i < arguments[1]; i++)
		  {
		  	if(i != cur){
		  	var select2 = document.getElementById("sltDeptNoProvided"+i);

		  	for (var j = 1; j < optionNo; j++) {
		  		for(var k = 0; k < indexSelected.length ; k++ ){
		  			if(indexSelected[k] == j){
		  				select2.item(j).className = "test";
		  				break ;
		  			}else{
		  				select2.item(j).className = "";
		  			}

		  				
		  			}
		  		}
		  	}
		  }
	}
</script>


</body>


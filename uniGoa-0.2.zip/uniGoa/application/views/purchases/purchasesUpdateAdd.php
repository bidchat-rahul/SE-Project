<head>
    <meta charset="UTF-8">
	<link rel="stylesheet" href="<?php echo base_url('assets/table.css')?>">  
</head>
<body>
<?php if (!is_null($tableData)) { ?>

<h2>Admin Id to The purchase items</h2>
<?php echo form_open('site/test'); ?>
<div>
<table class="container">
	<thead >
		<tr >
			<th>Date Of Purchase</th>
			<th>Qty</th>
			<th>Total Amt IncludeTax</th>
			<th>Budget Name</th>
			<th>Warranty Period</th>
			<th>File No</th>		
			<th>Item Name</th>
			<th>Brand Name</th>
			<th>Supplier Name</th>
			<th>Click</th>
		</tr>		
	</thead>
	<tbody  >
	<?php foreach ($tableData as $value) { ?>

		<tr>
			<td><?php echo $value->dateOfPurchase ?></td>
			<td><?php echo $value->qty ?></td>
			<td><?php echo $value->totalAmtIncludeTax ?></td>
			<td><?php echo $value->budgetName.": ".$value->budgetDescp ?></td>

			<td><?php echo $value->warrantyPeriod ?></td>
			<td><?php echo $value->fileNo ?></td>
			<td><?php echo $value->itemName ?></td>
			<td><?php echo $value->brandName ?></td>
			<td><?php echo $value->supplierName ?></td> 
			<td><a href="<?php echo base_url('index.php/site/loadPurchasesAdmin') ?><?php echo '/'.$value->id ?>" > Add </a></td>
		</tr>
	<?php
	} ?>
	</tbody>
</table>

<?php }else{ ?>

<h2>There are No items without Admin Id</h2>

<?php } ?>

<?php echo form_close(); ?>
</body>
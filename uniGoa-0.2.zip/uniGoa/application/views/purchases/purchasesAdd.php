<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="<?php echo base_url('assets/demo.css')?>">
        <link rel="stylesheet" href="<?php echo base_url('assets/demo1.css')?>">
    </head>
    <body>
<center><h2><font color="white">Insert Purchases</font></h2></center>
<?php echo form_open('site/loadPurchasesAdd'); ?>

<div>
<label for="lblDateOfPurchase" >Date of Purchases</label><!-- class="control-label col-md-3"  -->
	<div  id="form" class="form-horizontal"  >
	    <div class="form-body">
	        <div class="form-group">
	        <input name="dtpkrDateOfPurchase" placeholder="yyyy-mm-dd" class="form-control datepicker" type="text" required="true">
<!-- 	            <div class="col-md-3">
	                
	            </div> -->
	        </div>
	    </div>
	</div>  

<script type="text/javascript">

$(document).ready(function() {
    $('.datepicker').datepicker({
        autoclose: true,
        format: "yyyy-mm-dd",
        todayHighlight: true,
        orientation: "top left",
        todayBtn: true,
        todayHighlight: true,  
    });

});

</script> 


</div>

<div>
	<label for="lblItemBrand">Item Brand</label>
	<select id="sltCategory_name" name="sltCategory_name" required="true" onchange="this.form.submit();">
		<option value="">Please select</option>
	<?php foreach ($category as $value) { ?>
		
		<option value="<?php echo $value->name ?>" 
			<?php

	        if ($value->name == $id) {
		        	echo "selected";}

		    ?> 


		><?php echo $value->name ?></option>

	<?php
	} ?>

	</select>

</div>

<div>
	<label for="lblItemType">Item Type</label>

		<select id="sltItems_name" name="sltItems_name" required="true">
		<option value="">Please select</option>
	<?php foreach ($item as $value) { ?>
		<option value="<?php echo $value->name ?>" ><?php echo $value->name ?></option>

	<?php
	} ?>
	</select>
</div>

<div>
	<label for="lblDescOfItem">Desc Of Items</label>
	<textarea id="txtarDescOfItem" name="txtarDescOfItem" required="true"></textarea>
</div>

<div>
	<label for="lblWarrantyPeriod">Warenty period in months</label>
	<input type="number" id="txtWarrantyPeriod" min="1" name="txtWarrantyPeriod" required="true"></input>
</div>

<div>
	<label for="lblQty">Qty</label>
	<input type="number" id="txtQty" name="txtQty" min="1" required="true"></input>
</div>

<div>
	<label for="lblUnitPrice">per Unit Price</label>
	<input type="number" id="txtUnitPrice" name="txtUnitPrice" min="0" step="0.01" required="true"></input>
</div>

<div>
	<label for="lblTaxAmt">Tax Amt (Rs.)</label>
	<input type="number" id="txtTaxAmt" name="txtTaxAmt" step="0.01" min="0" required="true"></input>
	<!--total amt = (unitPrice*qty)+tax Amt -->
</div>

<div>
	<label for="lblSupplierId">Supplier name</label>
	<select id="sltSuppliers_name" name="sltSuppliers_name" required="true">
	<option value="">Please select</option>
	<?php foreach ($supplier as $value) { ?>

		<option value="<?php echo $value->id ?>" ><?php echo $value->name ?></option>

	<?php
	} ?>
	</select>
</div>

<div>
	<label for="lblBudgetHead">Budget Head</label>
	<select id="sltBudgetList_name" name="sltBudgetList_name" required="true">
	<option value="">Please select</option>
	<?php foreach ($budget as $value) { ?>

		<option value="<?php echo $value->id ?>" > <?php echo $value->year ?> :<?php echo $value->name.":".$value->descp ?></option>

	<?php
	} ?>
	</select>
</div>

<div>
	<label for="lblFileNo">File No</label>
	<input type="text" id="txtFileNo" name="txtFileNo" required="true"></input>
</div>

<div>
	<button formaction="<?php echo base_url('index.php/site/addPurchases')?>">Submit</button>
</div>

<!--
filled afterwords initaily null
redirected to purchasesUpdateAdd.php
<div>
	<label for="lblAdminBlockNo">Admin Block No Provied</label>
	<input type="text" id="txtAdminBlockNo" name="txtAdminBlockNo"></input>
</div>
-->

<?php echo form_close(); ?>
</body>
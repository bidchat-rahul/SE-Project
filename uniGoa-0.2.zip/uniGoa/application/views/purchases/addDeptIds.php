<head>
    <meta charset="UTF-8">
		<title> </title>
				<link rel="stylesheet" href="<?php echo base_url('assets/table.css')?>">  
</head>
<body>
<?php  echo form_open('site/addDeptId'); 


echo form_hidden('purchaseId', $purchaseId);
echo form_hidden('boxNo', $numberReq);

for ($i=0; $i < $numberReq; $i++){ ?>

<div>
	<label for="lblDeptNoProvided">Department No Provided</label>
	<input type="text" name="txtDeptNoProvided<?php echo $i?>" id="txtDeptNoProvided<?php echo $i?>" ></input>
</div>

	<?php	} ?>
<div>
	<button>Submit</button>
</div>

<?php echo form_close();?>
</body>

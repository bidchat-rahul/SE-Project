<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sign Up Form</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/demo.css')?>">
        <link rel="stylesheet" href="<?php echo base_url('assets/demo1.css')?>">
</head>
<body>
<h2>Insert budget</h2>
<?php echo form_open('site/addBugetList'); ?>
<div>
	 <label for="lblName">Budget Head :</label>
	 <input type="text" name="txtName" required="true" id="txtName"></input>

</div>
<div>
	 <label for="lblDescp">Name:</label>
	 <input type="text" name="txtDescp" required="true" id="txtDescp"></input>	
</div>
<div>

	 <label for="lblReasons">Reasons:</label>
	 <textarea name="txtReasons" id="txtReasons" required="true"></textarea>
	 
</div>

<div>

	 <label for="lblRemarks">Remarks:*</label>
	 <input type="text" name="txtRemarks"  id="txtRemarks"></input>
</div>


<div>
	<button>Submit</button>

</div>

<?php echo form_close(); ?>
</body>
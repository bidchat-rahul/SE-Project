<?php

class site_model extends CI_Model
{
	//item add functinality
	function listItem($value)
	{
		$sql = "SELECT distinct name FROM items where categoryId = '$value'";
		$query = $this->db->query($sql);
		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}
	function listItem1()
	{
		$sql = "SELECT distinct name FROM items ";
		$query = $this->db->query($sql);
		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}
	function listCategary()
	{
		$query = $this->db->query('SELECT name FROM category ');

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}


	function insertItems($data){
		$this->db->insert('items',$data);
		return 1;
	}
	function insertCategory($data){
		$this->db->insert('category',$data);
		return 1;
	}

	function chkCategory($value)
	{
		$query = $this->db->query("SELECT name FROM category WHERE name = '$value' ");

		if ($query->num_rows()>0){
			return false;
		}else
			return true;
	}

	function chkItem($value)
	{
		$name = $value['name'] ;
		$category = $value['categoryId'] ;
		$sql = "SELECT name , categoryId  FROM items WHERE name = '$name' and categoryId = '$category' ";
		$query = $this->db->query($sql);

		if ($query->num_rows()>0){
			return false;
		}else
			return true;
	}

	//Add Suppliers functionality
	function insertSuppliers($data)
	{
		$this->db->insert('suppliers', $data);
		//to get the currntly inserted  id
		$t=$this->db->insert_id();
		return 1;
	}

	function insertSuppliersCategory($data){
		
		$this->db->insert('suppliersCategory',$data);
		return 1;
	}

	function listSupliers()
	{
		$query = $this->db->query('SELECT id, name FROM suppliers');

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}
	function listSupliersCattegory(){
		$query = $this->db->query('SELECT id, name FROM suppliersCategory ');

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}
	function listSupliersCattegory1($value){
		$sql = "SELECT id, name FROM suppliersCategory where name = '$value' ";

		$query = $this->db->query($sql);

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}
	function chkCanSupply($value)
	{
		$supId = $value['supplierId'];
		$catId = $value['supplierCatId'] ;
		$query = $this->db->query("SELECT supplierId FROM canSupply WHERE supplierId = '$supId' and supplierCatId = '$catId'");

		if ($query->num_rows()>0){
			return false;
		}else
			return true;
	}
	function insertCanSupply($data)
	{
		$this->db->insert('canSupply',$data);
		return 1;
	}

	//add room
	function chkRoomType($value)
	{
		$name = $value['name'];
		$query = $this->db->query("SELECT name FROM roomType WHERE name = '$name'");

		if ($query->num_rows()>0){
			return false;
		}else
			return true;
	}

	function insertRoomType($data)
	{
		$this->db->insert('roomType',$data);
		return 1;
	}
	//room update
	function getUpdateRoomData($id){
		$query = $this->db->query("SELECT name, capacity, desc FROM roomType WHERE id = '$id' ");

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}

	function updateRoomType($room)
	{
		$id = $room['id'];
		$name = $room['name'];
		$capacity = $room['capacity'] ;
		$desc = $room['desc'];
		$this->db->query("UPDATE `roomType` SET `name`='$name',`capacity`='$capacity',`desc`='$desc' WHERE `id`='$id'");
		return 1;
	}

	//add budget
	function insertBudgetList($data)
	{
		$this->db->insert('budgetList',$data);
		return 1;
	}
	function chkBudgetList($value){
		$name = $value['name'];
		$query = $this->db->query("SELECT name FROM budgetList WHERE name = '$name'");

		if ($query->num_rows()>0){
			return false;
		}else
			return true;

	}
	//add budget recourds
	function listBudgetList(){
		$query = $this->db->query("SELECT name , descp FROM budgetList");

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null ;
	}

	function insertBudgetRecourds($budget){
		$this->db->insert('budgetRecourds',$budget);
		return 1;
	}
	//add purchases
	function getItemSerialNo($values){
		$name = $values['name'];
		$catId = $values['catId'];
		$sql = "SELECT serialNo FROM items WHERE name = '$name' and categoryId = '$catId'" ; 

		$query = $this->db->query($sql);

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;

	}
	function listPurchasesAdminIdRequerd(){
		$sql = "SELECT purchases.id , `dateOfPurchase`, `qty`, `totalAmtIncludeTax`,budgetList.name as budgetName,budgetList.descp as budgetDescp, `warrantyPeriod`, `fileNo`, items.name as itemName,items.categoryId as brandName,suppliers.name as supplierName FROM `purchases` ,items,suppliers ,budgetRecourds ,budgetList where suppliers.id = purchases.supplierId and items.serialNo = purchases.itemSerialNo and purchases.budgetHead = budgetRecourds.id and budgetRecourds.budgetListId = budgetList.name and adminBlockNo is null ";


		$query = $this->db->query($sql);

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;

	}

	function listPurchasesDeptIdRequerd()
	{
		$sql = "SELECT purchases.id , `dateOfPurchase`,qty as bqty, qty - allotedQty as qty, `totalAmtIncludeTax`,budgetList.name as budgetName,budgetList.descp as budgetDescp, `warrantyPeriod`, `fileNo`, items.name as itemName,items.categoryId as brandName,suppliers.name as supplierName FROM `purchases` ,items,suppliers ,budgetRecourds ,budgetList,temp where suppliers.id = purchases.supplierId and items.serialNo = purchases.itemSerialNo and purchases.budgetHead = budgetRecourds.id and budgetRecourds.budgetListId = budgetList.name and purchases.id = temp.purchasesId having qty >0 
UNION 
SELECT purchases.id , `dateOfPurchase`, qty ,qty as bqty, `totalAmtIncludeTax`,budgetList.name as budgetName,budgetList.descp as budgetDescp, `warrantyPeriod`, `fileNo`, items.name as itemName,items.categoryId as brandName,suppliers.name as supplierName FROM `purchases` ,items,suppliers ,budgetRecourds ,budgetList where suppliers.id = purchases.supplierId and items.serialNo = purchases.itemSerialNo and purchases.budgetHead = budgetRecourds.id and budgetRecourds.budgetListId = budgetList.name and purchases.id not in (select distinct purchasesId from  temp)";

		$query = $this->db->query($sql);

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;


	}

	function listSubPlace($roomId)
	{
		$sql = "SELECT distinct `subPlace` FROM `itemPlaced` WHERE `roomTypeId` = $roomId ";

		$query = $this->db->query($sql);

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}

	function listBudgetRecourds(){

		$sql = "SELECT budgetRecourds.id as id , year, budgetList.name as name , budgetList.descp as descp FROM budgetRecourds , budgetList where budgetList.name = budgetRecourds.budgetListId order by year desc ";

		$query = $this->db->query($sql);

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;

	}

	function insertPurchases($purchases)
	{
		$this->db->insert('purchases',$purchases);
		return $this->db->insert_id();
	}

	function updatePurchases($value)
	{
		//print_r($value);
		$this->db->where('id', $value['id']);
		$this->db->update('purchases', $value);
		return 1;
	}
	function updatePurchasesSetQty($id)
	{
		$sql = "UPDATE purchases SET placeQty = placeQty + 1 WHERE id = $id";

		$this->db->query($sql);
		return 1;
	}

	function insertItemsPlace($data)
	{
		$this->db->insert('itemPlaced',$data);
		return 1;
	}

	function insertDeptId($values)
	{
		return $this->db->insert('departmentIdsItems',$values);
		
	}

	function listItemsNotAllocatedPlace()
	{
	 	$sql = "SELECT purchases.id as pid , dateOfPurchase, qty - `placeQty` as qty, totalAmtIncludeTax,budgetList.name as budgetName,budgetList.descp as budgetDescp, warrantyPeriod, fileNo, items.name as itemName,items.categoryId as brandName,suppliers.name as supplierName FROM purchases ,items,suppliers ,budgetRecourds ,budgetList where suppliers.id = purchases.supplierId and items.serialNo = purchases.itemSerialNo and purchases.budgetHead = budgetRecourds.id and budgetRecourds.budgetListId = budgetList.name having `qty` > 0 ";


		$query = $this->db->query($sql);

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;

	}
	function listBudgetRecourdsCondition($value)
	{
		$sql ="SELECT amtProvided, amtSpend, budgetListId,descp FROM budgetRecourds ,budgetList WHERE budgetRecourds.budgetListId = budgetList.name and year = $value ";

		$query = $this->db->query($sql);

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;

	}

	function listBudgetRecourdsYear()
	{
		$sql ="SELECT distinct year FROM budgetRecourds";

		$query = $this->db->query($sql);

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}
	//reports Section defective list

	function defectiveList()
	{
		$query = $this->db->query('select items.name , categoryId , reason from items ,purchases , itemPlaced ,defactive where items.serialNo = purchases.itemSerialNo  and purchases.id = itemPlaced.purchaseId and itemPlaced.id = defactive.itemPlaceId');

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}

	//list defective items of perticular category

	function defectiveCat($value)
	{
		$query = $this->db->query("select items.name , categoryId , reason from items ,purchases , itemPlaced ,defactive where items.serialNo = purchases.itemSerialNo  and purchases.id = itemPlaced.purchaseId and itemPlaced.id = defactive.itemPlaceId and items.name = '$value'");

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}

	//list of suppliers who can supply particular product

	function supplierPerProduct($value)
	{
		$query = $this->db->query("select suppliers.name as sname, suppliers.address, suppliers.contactNo, suppliers.email from suppliers, canSupply, suppliersCategory where suppliers.id = canSupply.supplierId and canSupply.supplierCatId = suppliersCategory.id and suppliersCategory.name = '$value'");

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}

	//list of items in a perticular room

	function itemInRoom($room)
	{
		$sql = "select items.name , categoryId ,subPlace ,itemPlaced.deptNoProvided as deptNo from items ,purchases , itemPlaced, roomType,departmentIdsItems where items.serialNo = purchases.itemSerialNo and purchases.id = departmentIdsItems.purchasesId and itemPlaced.deptNoProvided = departmentIdsItems.id and itemPlaced.roomTypeId = roomType.id and roomType.name = '$room' ";


		$query = $this->db->query($sql);

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}

	function listRoom(){
		$sql = "SELECT id, name FROM roomType ";

		$query = $this->db->query($sql);

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}

	//list of maintenance items along with maintaner name for perticuler time period

	function listMaintenarName($data)
	{
		$startDate = $data['startDate'];
		$endDate = $data['endDate'];
		$sql = "select maintanance.amcEndDate,maintanance.amcStartDate,dateOfPurchase,items.name as iname,maintanance.amt,maintanance.remark,suppliers.name,suppliers.contactNo,suppliers.email, suppliers.address from maintananceBy , maintanance , suppliers ,purchases , items where suppliers.id = maintananceBy.supplierId and maintananceBy.mentenanceId = maintanance.serialNo and purchases.id = maintanance.purchasesId and purchases.itemSerialNo = items.serialNo and amcStartDate >= '$startDate' and amcEndDate <= '$endDate' ";


		$query = $this->db->query($sql);

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}
	//list purchasses

	function listPurchases($value)
	{
		$startDate = $value['startDate'];
		$endDate = $value['endDate'];

		$sql = "SELECT purchases.id , dateOfPurchase, qty, totalAmtIncludeTax,budgetList.name as budgetName,budgetList.descp as budgetDescp, warrantyPeriod, fileNo, items.name as itemName,items.categoryId as brandName,suppliers.name as supplierName FROM purchases ,items,suppliers ,budgetRecourds ,budgetList where suppliers.id = purchases.supplierId and items.serialNo = purchases.itemSerialNo and purchases.budgetHead = budgetRecourds.id and budgetRecourds.budgetListId = budgetList.name and dateOfPurchase between '$startDate' and '$endDate'";

		$query = $this->db->query($sql);

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;



	}


	//Details of Supliers

	function suplierList(){
		$sql = "SELECT   id, name, address, contactNo,contactName, email  FROM suppliers";

		//$this->db->limit(2,0);

		$query = $this->db->query($sql);

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;

	}


	function supplierList1($limit,$offset){
		$sql = "SELECT id, name, address, contactNo,contactName, email FROM suppliers limit $limit offset $offset";

		//$this->db->limit($limit,$offset);
		$query = $this->db->query($sql);

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;

	}


	//details of departmentId
	function deptIdOnKey($value)
	{
		$sql = "SELECT id, deptNoProvided FROM itemPlaced WHERE roomTypeId = $value";

		$query = $this->db->query($sql);

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;

	}

	function updateItemPlace($data){
		$id = $data['updateId'];
		$subPlace = $data['subPlace'];
		$roomTypeId =$data['roomTypeId'];
		$sql = "UPDATE itemPlaced SET subPlace= '$subPlace',roomTypeId= $roomTypeId WHERE id = $id";
		$query = $this->db->query($sql);
		return 1;
	}

	function updateFullData($value)
	{
		$sql = "SELECT id, qty, unitPrice, totalAmtIncludeTax, adminBlockNo, budgetHead, warrantyPeriod, descOfItem, fileNo, supplierId, itemSerialNo FROM purchases WHERE id = $value";

		$query = $this->db->query($sql);

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;

	}
	function updateBudget($value,$amt)
	{
	
	$sql = "UPDATE budgetRecourds SET amtSpend = amtSpend + $amt WHERE id = $value";
	$this->db->query($sql);
	return 1;
	}


	function listMaintainanceRequerd($value){
		$sql = "SELECT purchases.id , `dateOfPurchase`, (qty - `removedQty`) as qty, `totalAmtIncludeTax`,budgetList.name as budgetName,budgetList.descp as budgetDescp,DATE_ADD(`dateOfPurchase`,INTERVAL `warrantyPeriod` MONTH) AS warrantyExp , `fileNo`, items.name as itemName,items.categoryId as brandName,suppliers.name as supplierName FROM `purchases` ,items,suppliers ,budgetRecourds ,budgetList where suppliers.id = purchases.supplierId and items.serialNo = purchases.itemSerialNo and purchases.budgetHead = budgetRecourds.id and budgetRecourds.budgetListId = budgetList.name and purchases.id  not in (select purchasesId from maintanance )  and DATEDIFF(DATE_ADD(`dateOfPurchase`,INTERVAL `warrantyPeriod` MONTH),CURDATE()) <= $value ";


		$query = $this->db->query($sql);

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;

	}

	function listMaintainanceRenewRequerd($value)
	{
		$sql ="SELECT maintanance.serialNo , `dateOfPurchase`, (qty - `removedQty`) as qty,maintanance.amt as totalAmtIncludeTax ,budgetList.name as budgetName,budgetList.descp as budgetDescp,`amcEndDate` , `amcStartDate`, `fileNo`, items.name as itemName,items.categoryId as brandName,suppliers.name as supplierName FROM `purchases` ,items,suppliers ,budgetRecourds ,budgetList,maintanance,maintananceBy where suppliers.id = maintananceBy.supplierId and maintananceBy.`mentenanceId` = maintanance.serialNo and items.serialNo = purchases.itemSerialNo and purchases.budgetHead = budgetRecourds.id and budgetRecourds.budgetListId = budgetList.name and purchases.id = maintanance.purchasesId and DATEDIFF(CURDATE(),`amcEndDate`) <= $value";

		$query = $this->db->query($sql);

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;


	}

	function insertMaintainance($data)
	{
		$this->db->insert('maintanance',$data);
		return $this->db->insert_id();
	}

	function insertMaintainanceBy($values)
	{
		$this->db->insert('maintananceBy',$values);
		return 1;
	}

	function maintananceList($value)
	{
		$sql ="SELECT `serialNo`, `amcStartDate`, `amcEndDate`, `remark`, `conditions`, maintanance.amt, `budgetHead`,supplierId FROM `maintanance` , maintananceBy WHERE maintanance.`serialNo` = maintananceBy.mentenanceId and `serialNo` = $value ";

		$query = $this->db->query($sql);

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}

	function updateMaintainance($data,$value)
	{
		//print_r($value);
		$this->db->where('serialNo', $value);
		$this->db->update('maintanance', $data);
		return 1;
	}
	function updateMaintainanceBy($data,$value)
	{
		$this->db->where('mentenanceId', $value);
		$this->db->update('maintananceBy', $data);
		return 1;
	}
	
	function listOnlyDeptIdNotAlloted($purchaseId)
	{
		$sql = "SELECT `id` FROM `departmentIdsItems` WHERE `purchasesId` = $purchaseId and `id` not in (select `deptNoProvided` from itemPlaced)";

		$query = $this->db->query($sql);

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}

 public function check_login($username,$password)
 {
   $this->db->select('username, password');
   $this->db->from('user');
   $this->db->where('username', $username);
   $this->db->where('password', $password);
   $this->db->limit(1);
   $result = $this->db->get();

     if($result->num_rows() == 1 )
       {
       	  $row = $result->row();
          $data = array(
					
					'username' => $row->username,
					'password' => $row->password,
            		'logged_in' => true
					);
			$this->session->set_userdata($data);

	return true;
   }
       else
       {
        return false;

       }
 }
}
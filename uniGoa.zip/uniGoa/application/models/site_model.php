<?php

class site_model extends CI_Model
{
	//item add functinality
	function listItem()
	{
		// $query = $this->db->query('SELECT distinct name FROM items');

		// if ($query->num_rows()>0){
		// 	return $query->result();
		// }else
		// 	return null;

		$query = $this->db->query('SELECT distinct serialNo,name FROM items');
		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}
	function listCategary()
	{
		$query = $this->db->query('SELECT name FROM category ');

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}


	function insertItems($data){
		$this->db->insert('items',$data);
		return 1;
	}
	function insertCategory($data){
		$this->db->insert('category',$data);
		return 1;
	}

	function chkCategory($value)
	{
		$query = $this->db->query("SELECT name FROM category WHERE name = '$value' ");

		if ($query->num_rows()>0){
			return false;
		}else
			return true;
	}

	function chkItem($value)
	{
		$query = $this->db->query("SELECT name , categoryId  FROM items WHERE name = '$name' and categoryId = '$category' ");

		if ($query->num_rows()>0){
			return false;
		}else
			return true;
	}

	//Add Suppliers functionality
	function insertSuppliers($data)
	{
		$this->db->insert('suppliers', $data);
		return 1;
	}

	function insertSuppliersCategory($data){
		$this->db->insert('suppliersCategory',$data);
		return 1;
	}

	function listSupliers()
	{
		$query = $this->db->query('SELECT id, name FROM suppliers');

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}
	function listSupliersCattegory(){
		$query = $this->db->query('SELECT id, name FROM suppliersCategory ');

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}
	function chkCanSupply($value)
	{
		$supId = $value['supplierId'];
		$catId = $value['supplierCatId'] ;
		$query = $this->db->query("SELECT supplierId FROM canSupply WHERE supplierId = '$supId' and supplierCatId = '$catId'");

		if ($query->num_rows()>0){
			return false;
		}else
			return true;
	}
	function insertCanSupply($data)
	{
		$this->db->insert('canSupply',$data);
		return 1;
	}

	//add room
	function chkRoomType($value)
	{
		$name = $value['name'];
		$query = $this->db->query("SELECT name FROM roomType WHERE name = '$name'");

		if ($query->num_rows()>0){
			return false;
		}else
			return true;
	}

	function insertRoomType($data)
	{
		$this->db->insert('roomType',$data);
		return 1;
	}
	//room update
	function getUpdateRoomData($id){
		$query = $this->db->query("SELECT name, capacity, desc FROM roomType WHERE id = '$id' ");

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}

	function updateRoomType($room)
	{
		$id = $room['id'];
		$name = $room['name'];
		$capacity = $room['capacity'] ;
		$desc = $room['desc'];
		$this->db->query("UPDATE `roomType` SET `name`='$name',`capacity`='$capacity',`desc`='$desc' WHERE `id`='$id'");
		return 1;
	}

	//add budget
	function insertBudgetList($data)
	{
		$this->db->insert('budgetList',$data);
		return 1;
	}
	function chkBudgetList($value){
		$id = $value['id'];
		$query = $this->db->query("SELECT id FROM budgetList WHERE id = '$id'");

		if ($query->num_rows()>0){
			return false;
		}else
			return true;

	}
	//add budget recourds
	function listBudgetList(){
		$query = $this->db->query("SELECT id ,name FROM budgetRecourds");

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null ;
	}

	function insertBudgetRecourds($budget){
		$this->db->insert('budgetRecourds',$budget);
		return 1;
	}
	//add purchases
	function getItemSerialNo($values){
		$name = $values['name'];
		$catId = $values['catId'];
		$sql = "SELECT serialNo FROM items WHERE name = '$name' and categoryId = '$catId'" ; 

		$query = $this->db->query($sql);

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;

	}

	function insertPurchases($purchases)
	{
		$this->db->insert('purchases',$purchases);
		return 1;
	}


	//reports Section defective list

	function defectiveList()
	{
		$query = $this->db->query('select items.name , categoryId , reason from items ,purchases , itemPlaced ,defactive where items.serialNo = purchases.itemSerialNo  and purchases.id = itemPlaced.purchaseId and itemPlaced.id = defactive.itemPlaceId');

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}

	//list defective items of perticular category

	function defectiveCat($value)
	{
		$query = $this->db->query("select items.name , categoryId , reason from items ,purchases , itemPlaced ,defactive where items.serialNo = purchases.itemSerialNo  and purchases.id = itemPlaced.purchaseId and itemPlaced.id = defactive.itemPlaceId and items.name = '$value'");

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}

	//list of suppliers who can supply particular product

	function supplierPerProduct($value)
	{
		$query = $this->db->query("select suppliers.name as sname, suppliers.address, suppliers.contactNo, suppliers.email from suppliers, canSupply, suppliersCategory where suppliers.id = canSupply.supplierId and canSupply.supplierCatId = suppliersCategory.id and suppliersCategory.name = '$value'");

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}

	//list of items in a perticular room

	function itemInRoom($room)
	{
		$sql = "select items.name , categoryId ,subPlace from items ,purchases , itemPlaced, roomType where items.serialNo = purchases.itemSerialNo and purchases.id = itemPlaced.purchaseId and itemPlaced.roomTypeId = roomType.id and roomType.name = '$room' ";


		$query = $this->db->query($sql);

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}

	function listRoom(){
		$sql = "SELECT id, name FROM roomType ";

		$query = $this->db->query($sql);

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}

	//list of maintenance items along with maintaner name for perticuler time period

	function listMaintenarName($data)
	{
		$startDate = $data['startDate'];
		$endDate = $data['endDate'];
		$sql = "select maintanance.amcEndDate,maintanance.amcStartDate,dateOfPurchase,items.name as iname,maintanance.amt,maintanance.remark,suppliers.name,suppliers.contactNo,suppliers.email, suppliers.address from maintananceBy , maintanance , suppliers ,purchases , items where suppliers.id = maintananceBy.supplierId and maintananceBy.mentenanceId = maintanance.serialNo and purchases.id = maintanance.purchasesId and purchases.itemSerialNo = items.serialNo and amcStartDate >= '$startDate' and amcEndDate <= '$endDate' ";


		$query = $this->db->query($sql);

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;
	}

	//Details of Supliers

	function suplierList(){
		$sql = "SELECT  name, address, contactNo, email FROM suppliers";


		$query = $this->db->query($sql);

		if ($query->num_rows()>0){
			return $query->result();
		}else
			return null;

	}





	
	function getAll()
	{
		$q = $this->db->get('temp');
                           
		if ($q->num_rows()>0){
			return $q->result();
		}else
		return null;
	}

	function add_records($data){
		$this->db->insert('temp',$data);
		return;
	}

	function update_record($data){
		$this->db->where('id',4);
		$this->db->update('temp',$data);
	}
     
     function delete_row(){
     	//echo $this->url->segment(3);
     	//$segments = array('news', 'local', '123');
		//echo $this->url->segment(3);
		//echo site_url($segments);
     	//echo site_url(segment(3));
     	$this->db->where('id',$this->uri->segment(3));
     	$this->db->delete('temp');

     }
}
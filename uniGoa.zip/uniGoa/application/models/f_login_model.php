<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 class F_login_model extends CI_Model 
 {
     public function index()
     {
     	echo 'how r you';
     }
    

 
 public function check_login($username,$password)
 {
      /*$sha1_password = sha1($password);
      $query_str = " SELECT id from user where username = ? and password = ? ";
      $result = $this->db->query($query_str,array($username,$sha1_password));
*/


   //echo $username;



 

    $this->db->select('username, password');
   $this->db->from('user');
   $this->db->where('username', $username);
   $this->db->where('password', $password);
   $this->db->limit(1);
   $result = $this->db->get();
     // echo $username;


  //$result = $this->db->get();

     // print_r ($result->result());
       //  print_r ($result->num_rows());
           // print_r ($query->row());
     if($result->num_rows() == 1 )
       {
       	  $row = $result->row();
          $data = array(
					
					'username' => $row->username,
					'password' => $row->password,
            'logged_in' => true
					//'validated' => true
					);
			$this->session->set_userdata($data);
     // echo $this->session->userdata['username'];
			return true;

       }
       else
       {

        return false;

       }



 }




 }

<?php

class site extends CI_Controller{
	function test(){
		print_r($_POST);
	}
	//Add Items
	function addItem(){

		$dataCategory = array(
			'name' => $this->input->post('lstCategoryName')
			);

		$data = array(
			'name' => $this->input->post('txtName'),
			'remark' => $this->input->post('txtarRemark'),
			'categoryId' => $this->input->post('lstCategoryName')
			);
		//if category_name not present in category then only insert in category :-done
		//insert only if category_name and item type not present in items msg alrady present :-done 
		//Check item type must be in Non-numeric
		$chkCat = $this->site_model->chkCategory($dataCategory['name']);

		if ($chkCat) {
			echo "inserted cat" ;
			$this->site_model->insertCategory($dataCategory);
		}

		$chkItm = $this->site_model->chkItem($data); 

		if ($chkItm) {
			echo "inserted item" ;
			$this->site_model->insertItems($data);
		}	

		$this->loadItemAdd();
	}

	//Add Suppliers
	function addSuppliers()
	{
		$data = array(
			'name' => $this->input->post('txtName'),
			'address' => $this->input->post('txtarAddress'),
			'contactNo' => $this->input->post('txtContactNo'),
			'email' => $this->input->post('txtEmail')
			);

		$this->site_model->insertSuppliers($data);
		$this->loadSuppliersAdd();
	}

	//Add Supplier category
	function addSuppliersCategory(){
		$data = array(
			'name' => $this->input->post('txtName'),
			'remark' => $this->input->post('txtarRemark')
			);
		$this->site_model->insertSuppliersCategory($data);
		$this->loadSuppliersCategoryAdd();

	}

	//Add can supply 
	function addCansupply(){
		$data = array(
			'supplierCatId' => $this->input->post('sltSupplierCatId'),
			'supplierId' => $this->input->post('sltSupplierId')
			);

		$chkCat = $this->site_model->chkCanSupply($data);
		
		if ($chkCat) {
			$this->site_model->insertCanSupply($data);
		}
		$this->loadCanSupply();

	}

	// Add room Details
	function addRoom()
	{
		$values = array(
			'capacity' => $this->input->post('txtCapacity'),
			'desc' => $this->input->post('txtarDesc'),
			'name' => $this->input->post('txtName')
			);
		$chkRoom = $this->site_model->chkRoomType($values);

		if ($chkRoom) {
			$this->site_model->insertRoomType($values);
		}
		$this->loadRoomTypeAdd();
	}
	//change room details find more tomarrow
	function loadUpdateRoom()
	 {
	 	$id = $this->input->post('sltName');

	 	$showData = $this->site_model->getUpdateRoomData($id);
	 	$this->loadRoomTypeUpdate($showData);

	 } 
	 public function getDetails()
	{
		$this->db->select("*");
		$this->db->from("roomType");
		$this->db->where("id",$_GET['id']);
		$data=$this->db->get()->row();
		echo json_encode($data);
	}
	 function updateRoomData()
	 {

		$values = array(
			'id'=>$this->input->post('sltName'),
			'capacity' => $this->input->post('txtCapacity'),
			'desc' => $this->input->post('txtarDesc'),
			'name' => $this->input->post('txtName')
			);
		$this->site_model->updateRoomType($values);
		$this->loadRoomTypeUpdate();

	 }

	 //add budget list
	 function addBugetList(){
	 	$budget = array(
			'id' => $this->input->post('txtId'),
			'desc' => $this->input->post('txtarDesc'),
			'name' => $this->input->post('txtName')
			);
	 	$chkBudget = $this->site_model->chkBudgetList($budget);

	 	if ($chkBudget) {
			$this->site_model->insertBudgetList($budget);
		}
	 	
	 	$this->loadBudgetAdd();
	 }
	 //add budget records
	 function addBudgetRecords(){
	 	$budget = array(
			'year' => $this->input->post('txtYear'),
			'budgetListId' => $this->input->post('sltBudgetListId'),
			'amtProvided' => $this->input->post('txtAmtProvided')
			);
	 	$this->site_model->insertBudgetRecourds($budget);
	 	$this->loadBudgetRecourds();

	 }
	 //add purchases
	 function addPurchases()
	 {

	 	$taxAmt = $this->input->post('txtTaxAmt');
	 	$qty = $this->input->post('txtQty');
	 	$unitPrice = $this->input->post('txtUnitPrice');

	 	$tempData = array(
			'name' => $this->input->post('sltItems_name'),
			'catId' => $this->input->post('sltCategory_name')
			);

	 	$name=$this->input->post('sltItems_name');
	 	$a=$this->input->post('sltCategory_name');
	 	$sql = "SELECT serialNo FROM items WHERE name = '$name' and categoryId = '$a'" ; 
	 	$query = $this->db->query($sql)->row();

		$total_amt = ($unitPrice * $qty)+$taxAmt;
	 	$purchases = array(
			'dateOfPurchase' =>$this->input->post('dtpkrDateOfPurchase'),
			'qty' =>$qty,
			'unitPrice' =>$unitPrice,
			'totalAmtIncludeTax' =>$total_amt,
			'budgetHead' =>$this->input->post('sltBudetList_name'),
			'warrantyPeriod' =>$this->input->post('txtWarrantyPeriod'),
			'descOfItem' =>$this->input->post('txtarDescOfItem'),
			'fileNo' =>$this->input->post('txtFileNo'),
			'supplierId' =>$this->input->post('sltSuppliers_name'),
			'itemSerialNo' =>$this->input->post('sltItems_name')
			);
	 	$this->site_model->insertPurchases($purchases);

	 }




/*
Report Section
select data from defective items :done
*/
	 function getDefectiveList(){

	 	$data['defective'] = $this->site_model->defectiveList();
	 	$this->load->view('reportsSection/reportDefectiveItems',$data);


	 }

	 function getDefectiveListCat(){ //done
	 	$data['itemName'] = 'Pc';
	 	$data['category'] = $this->site_model->listItem();
	 	$data['defectiveCat'] = $this->site_model->defectiveCat($data['itemName']); //like Pc laptop other
		$this->load->view('reportsSection/reportDefectiveListCondi',$data );

	 }

//done
	 function getSuplierDataOnCondition(){
	 	$data['itemName'] = 'Pc';
	 	$data['supplierCategory'] = $this->site_model->listSupliersCattegory();
	 	$data['suppliersProduct'] = $this->site_model->supplierPerProduct( $data['itemName'] ); 
	 	$this->load->view('reportsSection/reportSuppliersWhoSupplies',$data );

	 }

	 function getRoomData(){ //done
	 	$data['roomName'] = 'Lab 2';
	 	$data['listRoom'] = $this->site_model->listRoom();
	 	$data['room'] = $this->site_model->itemInRoom($data['roomName']); 
	 	$this->load->view('reportsSection/listRoomItem',$data );
	 }

	 function getMaintainerData(){
	 	$data['dates'] = array(
			'startDate' => '2016-04-2',
			'endDate' => '2016-04-30'
		);
	 	$data['maintainer'] = $this->site_model->listMaintenarName($data['dates']); //for a period of time
	 	$this->load->view('reportsSection/reportMaintainarData',$data);
	 	
	 }

	 function getSuplierData() //done
	 {
	 	$data['supplier'] = $this->site_model->suplierList();
	 	$this->load->view('reportsSection/supplierList',$data);
	 }










/*

	function sendValuesToVeiw(){
		$data["myValue"] = "Some String";
		$data["anotherValue"]="another string";
		$this->load->model('site_model');
		$data['table']=$this->site_model->getAll();
		$this->load->view("dataTest",$data);
	}

	function loadAddPg(){
		$this->load->view('optinals_view');
	}

	function create(){
		print_r($_POST);
		//echo $_POST['value'];
		/*$data = array(
			'id' => $this->input->post('id'),
			'date' => $this->input->post('date'),
			'value' => $this->input->post('value')
			
			);
		$this->load->model('site_model');
		$this->site_model->add_records($data);
		$this->loadAddPg();*/
/*	}
	function updateRecord(){
		$data = array(
			'value' => $this->input->post('value'),
			'date' => $this->input->post('date')
			);
		$this->load->model('site_model');
		$this->site_model->update_record($data);
		$this->loadAddPg();
	}
	function deleteRow(){
		$this->load->model('site_model');
		$this->site_model->delete_row();
		$this->loadAddPg();
	}
*/


	//Navigation Start from hear



	function loadLogin()
	{
		$this->load->view('login');
	}


	function loadStartPg(){
		$this->load->view('startPg');
	}

	function loadItemAdd(){
		$data['item']=$this->site_model->listItem();
		$data['category']=$this->site_model->listCategary();

		$this->load->view('items/itemAdd',$data);
	}
	function loadCategory(){ 		//not used see if required
		 $this->load->view('template');
		 	$this->load->view('category/categoryAdd');
 $this->load->view('template_footer');
	
	}

	function loadSuppliersAdd(){
 $this->load->view('template');
		$this->load->view('suppliers/suppliersAdd');
 $this->load->view('template_footer');		
	}


	function loadBudgetAdd(){
 $this->load->view('template');
		$this->load->view('budgetList/budgetListAdd');
		 $this->load->view('template_footer');
	}
	function loadBudgetRecourds(){

		 $this->load->view('template');
		$data['budget']=$this->site_model->listBudgetList();
		$this->load->view('budgetRecourds/budgetRecourdsAdd',$data);
		 $this->load->view('template_footer');
	}

	function loadCanSupply(){

		 $this->load->view('template');
		$data['supplier']=$this->site_model->listSupliers();
		$data['category']=$this->site_model->listSupliersCattegory();

		$this->load->view('canSupply/canSupplyAdd',$data);
		 $this->load->view('template_footer');
	}

	function loadDefective(){

		 $this->load->view('template');
		$this->load->view('defactive/defactiveAdd');
		 $this->load->view('template_footer');
	}

	function loadItemPlace(){
		 $this->load->view('template');
		$this->load->view('itemPlaced/itemPlacedAdd');
		 $this->load->view('template_footer');
	}

	function loadMaintananceAdd(){
		 $this->load->view('template');
		$this->load->view('maintanance/maintananceAdd');
		 $this->load->view('template_footer');
	}
	function loadMaintananceByAdd(){
		 $this->load->view('template');
		$this->load->view('maintananceBy/maintananceByAdd');
		 $this->load->view('template_footer');
	}
	function loadPurchasesAdd(){

		$data['supplier']=$this->site_model->listSupliers();
		$data['category']=$this->site_model->listCategary();
		$data['item']=$this->site_model->listItem();
		$data['budget']=$this->site_model->listBudgetList();
 $this->load->view('template');
		$this->load->view('purchases/purchasesAdd',$data);
		 $this->load->view('template_footer');
	}
	function loadPurchasesUpdate(){
		 $this->load->view('template');
		$this->load->view('purchases/purchasesUpdateAdd');
		 $this->load->view('template_footer');
	}
	function loadRoomTypeAdd(){
		 $this->load->view('template');
		$this->load->view('roomType/roomTypeAdd');
		 $this->load->view('template_footer');
	}
	function loadRoomTypeUpdate()
	{
		//$data['rooms']=$this->site_model->listRoom();
		$this->db->select("id, name");
		$this->db->from("roomType");
		$data['rooms']=$this->db->get();

 $this->load->view('template');
		$this->load->view('roomType/roomTypeUpdate',$data);
		 $this->load->view('template_footer');
	}

	function loadSuppliersCategoryAdd(){
		 $this->load->view('template');
		$this->load->view('suppliersCategory/suppliersCategoryAdd');
		 $this->load->view('template_footer');
	}

	function loadRoomMain(){
			 $this->load->view('template');
		$this->load->view('roomtype');
		 $this->load->view('template_footer');	
	}

	function loadBudgetMain(){
			 $this->load->view('template');
		$this->load->view('budget');
		 $this->load->view('template_footer');	
	}

	function loadSupplierMain(){
			 $this->load->view('template');
		$this->load->view('supplier');
		 $this->load->view('template_footer');	
	}
} 

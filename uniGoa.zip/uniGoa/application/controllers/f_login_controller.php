<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class F_login_controller extends CI_Controller {

	public function index()
{
 if($this->session->userdata['username']==''){
   $this->load->view('test');
  }
  else{
 $this->load->view('template');
 $this->load->view('maintanance/maintananceAdd');
 $this->load->view('template_footer');

    }
  }

public function logout()
  {
    $this->session->unset_userdata('username');
    redirect('f_login_controller/index');
  }


  public function login()
  {
    extract($_POST);
    $this->load->model('f_login_model');

     $id = $this->f_login_model->check_login($username, $password);

     if(!$id)
          {
            redirect($this->load->view('test'));
          }
           else
           {
           redirect('f_login_controller/index');
            }
   }



}
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/login.css');?>">
</head>
<body>
<?php echo form_open('http://localhost/uniGoa/index.php/f_login_controller/login'); ?>


<h2><span class="entypo-login"></span> Login</h2>
  <button class="submit"><span class="entypo-lock"></span></button>
  <span class="entypo-user inputUserIcon"></span>
  <input type="text" class="user" id="username" name="username" placeholder="ursername"/>
  <span class="entypo-key inputPassIcon"></span>
  <input type="password" class="pass" id="password" name="password" placeholder="password"/>




<?php echo form_close(); ?>
</body>
</html>
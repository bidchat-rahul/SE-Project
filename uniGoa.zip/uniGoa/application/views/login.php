<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php echo form_open('site/test');  ?>
<div>
	<label for="lblUsrName">User Name </label>
	<input type="text" id="txtUserName" name="txtUserName"></input>
</div>
<div>
	<label for="lblPasswd">Password </label>
	<input type="password" id="passwd" name="passwd"></input>
</div>
<div>
	<button>Submit</button>
</div>

<?php echo form_close();?>
</body>
</html>
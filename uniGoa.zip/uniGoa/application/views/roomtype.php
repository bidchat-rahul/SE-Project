<!DOCTYPE html>
<html>
<head>
	
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/log.css');?>">
</head>
<body>
<div class="div1">
<h2>Budget</h2>

<div>

	<a href="http://localhost/uniGoa/index.php/site/loadRoomTypeAdd">Room Add</a>
	<a href="http://localhost/uniGoa/index.php/site/loadRoomTypeUpdate">Room Update</a>

</div>
</div>
<?php echo form_close(); ?>

</body>
</html>
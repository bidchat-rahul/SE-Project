<!DOCTYPE html>
<html>
<head>
	
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/log.css');?>">
</head>
<body>
<div class="div1">
<h2>Budget</h2>

<div>

	<a href="http://localhost/uniGoa/index.php/site/loadSuppliersAdd">Supplier Add</a>
	<a href="http://localhost/uniGoa/index.php/site/loadSuppliersCategoryAdd">Supplier Category</a>

</div>
</div>
<?php echo form_close(); ?>

</body>
</html>
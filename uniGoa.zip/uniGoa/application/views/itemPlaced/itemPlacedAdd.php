<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<!--id :- autoIncreament
purchaseId :- inharitaded
varification :- notDone
status :- working

 -->
<h2>Insert itemPlaced this is filled after the purchases is been made </h2>
<p>requires Id from purchase table which is auto increament </p>

<?php  echo form_open('site/test'); ?>
<div>
<label for="lblDeptNoProvided">Department No Provided</label>
<input type="text" name="txtDeptNoProvided" id="txtDeptNoProvided"></input>

</div>
<div>
	<label for="lblRoomTypeId">Room Name</label>
	<select name="sltRoomType_name" id="sltRoomType_name" >
		<option>a</option>
	</select>
</div>

<div>
	<label for="lblSubPlace">Sub Place</label>
	<input name="txtSubPlace" id="txtSubPlace"></input>
</div>
<div>
	<button>Submit</button>
</div>

<?php echo form_close();?>
</body>
</html>
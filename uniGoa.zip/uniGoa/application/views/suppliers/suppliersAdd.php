<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h2>Insert Suppliers </h2>
<?php echo form_open('site/addSuppliers'); ?>
<div>
	<label for="lblName">Name</label>
	<input type="text" id="txtName" name="txtName" required="true"></input>
</div>
<div>
	<label for="lblAddress">Address</label>
	<textarea id="txtarAddress" name="txtarAddress" required="true"></textarea>
</div>
<div>
	<label for="lblContactNo">Contact No</label>
	<input type="number" id="txtContactNo" name="txtContactNo" required="true"></input>
</div>
<div>
	<label for="lblEmail">Email</label>
	<input type="email" id="txtEmail" name="txtEmail" required="true"></input>
</div>
<div>
	<button>Submit</button>
</div>
<?php echo form_close(); ?>
</body>
</html>
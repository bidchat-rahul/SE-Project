<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h2>Insert MaintananceBy</h2>
<?php echo form_open('site/test'); ?>
<div>
	<!-- a table will be displyed to the supplier which he had sign and the amt he had recieved. they have to select the maintanance  
	maintanance id will be stored in variables i.e arrey
	cat.name|item.name|purchase.qty|purchases.datePurchase|maintanance.startDate|maintanance.endDate|AmtSigned|maintananceBy.amt|maintananceBy.SupplierId|

	only maintananceBy.amt will be taken from the supplier
	-->

	<label>Amount Recieved </label>
	<input type="number" id="txtAmt" name="txtAmt" step="0.01"></input>

</div>

<div>
	<button>Submit</button>
</div>

<?php echo form_close(); ?>
</body>
</html>
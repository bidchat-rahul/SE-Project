<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<div>
	<label>Select Room</label>
	<select name="sltRoomName">
	<?php foreach ($listRoom as $value) { ?>

		<option value="<?php echo $value->id ?>" ><?php echo $value->name ?></option>

	<?php
	} ?>
	</select>
</div>
<h5>List of Items In Room <?php echo $roomName ?> </h5>

<table>
	<thead>
		<tr>
			<th>Item Brand</th>
			<th>Item Name</th>	
			<th>Location Number </th>
		</tr>
	</thead>

	<tbody>
		<?php foreach ($room as $value) { ?>
		<tr>
			<td><?php echo $value->categoryId ?></td>
			<td><?php echo $value->name ?></td>
			<td><?php echo $value->subPlace ?></td>
		</tr>
		<?php
		} ?>
	</tbody>

	
</table>


</body>
</html>
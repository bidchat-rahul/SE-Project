<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<div>
	<label>Select Item</label>
	<select name="sltSuppliersCategory">
	<?php foreach ($supplierCategory as $value) { ?>

		<option value="<?php echo $value->id ?>" ><?php echo $value->name ?></option>

	<?php
	} ?>
	</select>
</div>

<h5>Suppliers who can supply <?php echo $itemName ?> </h5>

<table>
	<thead>
		<tr>
			<th>Supplier Name</th>
			<th>Address </th>
			<th>Contact No</th>
			<th>Email </th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($suppliersProduct as $value) { ?>
		<tr>
			<td><?php echo $value->sname ?></td>
			<td><?php echo $value->address ?></td>
			<td><?php echo $value->contactNo ?></td>
			<td><?php echo $value->email ?></td>
		</tr>
		<?php
		} ?>
	</tbody>

	
</table>

</body>
</html>
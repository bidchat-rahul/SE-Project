<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h5>Defective Items</h5>

<table>
	<thead>
		<tr>
			<th>Item Name</th>	
			<th>Item Brand</th>
			<th>Reason of the Defect </th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($defective as $value) { ?>
		<tr>
			<td><?php echo $value->name ?></td>
			<td><?php echo $value->categoryId ?></td>
			<td><?php echo $value->reason ?></td>
		</tr>
		<?php
		} ?>
	</tbody>

	
</table>


</body>
</html>
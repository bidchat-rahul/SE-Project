<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link href= <?php  echo base_url('importsFile/bootstrap/css/bootstrap.min.css') ?> rel="stylesheet"  type="text/css" >
    <link href=<?php  echo base_url('importsFile/bootstrap-datepicker/css/bootstrap-datepicker3.min.css') ?> rel="stylesheet"  type="text/css" >

	<script src=<?php echo base_url('importsFile/jquery/jquery-2.1.4.min.js') ?>></script>
	<script src=<?php echo base_url('importsFile/bootstrap/js/bootstrap.min.js') ?> ></script>
	<script src=<?php echo base_url('importsFile/bootstrap-datepicker/js/bootstrap-datepicker.min.js') ?>>
	</script>
</head>
<body>
<?php echo form_open('site/test'); ?>
	<div  id="form" class="form-horizontal"  >
	    <div class="form-body">
	        <div class="form-group">
	            <label for="lblStartDate" class="control-label col-md-3" >From Period</label>
	            <div class="col-md-3">
	                <input name="dtpkrStartDate" placeholder="yyyy-mm-dd" class="form-control datepicker" required="true" type="text">
	            </div>
	        </div>
	    </div>
	</div>  

	<div  id="form" class="form-horizontal"  >
	    <div class="form-body">
	        <div class="form-group">
	            <label for="lblStartDate" class="control-label col-md-3" >To Period</label>
	            <div class="col-md-3">
	                <input name="dtpkrEndDate" placeholder="yyyy-mm-dd" class="form-control datepicker" required="true" type="text">
	            </div>
	        </div>
	    </div>
	</div>

	<button name="btnSubmit">Submit</button> 
	<?php echo form_close(); ?> 
<script type="text/javascript">

$(document).ready(function() {
    $('.datepicker').datepicker({
        autoclose: true,
        format: "yyyy-mm-dd",
        todayHighlight: true,
        orientation: "top left",
        todayBtn: true,
        todayHighlight: true,  
    });

});

</script> 
 

<h5>Maintainance Details for a period from <?php echo $dates['startDate'] ?> to <?php echo $dates['endDate'] ?> </h5>
 
<table>
	<thead>
		<tr>
			<th>AMC Start Date</th>	
			<th>AMC End Date</th>
			<th>Item Name</th>	
			<th>Date Of Purchase</th>			
			<th>Amount </th>
			<th>Name</th>	
			<th>Contact No</th>
			<th>Email </th>
			<th>Address</th>	
			<th>Remark</th>
						
		</tr>
	</thead>
	<tbody>
		<?php foreach ($maintainer as $value) { ?>
		<tr>
			<td><?php echo $value->amcStartDate ?></td>
			<td><?php echo $value->amcEndDate ?></td>
			<td><?php echo $value->iname ?></td>
			<td><?php echo $value->dateOfPurchase ?></td>				
			<td><?php echo $value->amt ?></td>
			<td><?php echo $value->name ?></td>
			<td><?php echo $value->contactNo ?></td>
			<td><?php echo $value->email ?></td>
			<td><?php echo $value->address ?></td>
			<td><?php echo $value->remark ?></td>

		</tr>
		<?php
		} ?>
	</tbody>

	
</table>


</body>
</html>
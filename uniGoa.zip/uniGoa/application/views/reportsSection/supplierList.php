<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h5>Supplier Details</h5>

<table>
	<thead>
		<tr>
			<th>Name</th>	
			<th>Address</th>
			<th>Contact No </th>
			<th>Email</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($supplier as $value) { ?>
		<tr>
			<td><?php echo $value->name ?></td>
			<td><?php echo $value->address ?></td>
			<td><?php echo $value->contactNo ?></td>
			<td><?php echo $value->email ?></td>
		</tr>
		<?php
		} ?>
	</tbody>

	
</table>


</body>
</html>
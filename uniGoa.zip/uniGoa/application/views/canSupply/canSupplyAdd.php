<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h2>Insert canSupply</h2>
<?php echo form_open('site/addCansupply'); ?>
<div>
<label for="lblSupCatId">Category :</label>
<select name="sltSupplierCatId" id="sltSupplierCatId" required="true">

	<?php foreach ($category as $value) { ?>

		<option value="<?php echo $value->id ?>" ><?php echo $value->name ?></option>

	<?php
	} ?>

</select>
</div><div>
<label for="lblSupplierId">Supplier :</label>
<select name="sltSupplierId" id="sltSupplierId" required="true">

	<?php foreach ($supplier as $value) { ?>

		<option value="<?php echo $value->id ?>" ><?php echo $value->name ?></option>

	<?php
	} ?>

</select>
</div>
<div>
	<button>Submit</button>
</div>
<?php echo form_close();?>
</body>
</html>
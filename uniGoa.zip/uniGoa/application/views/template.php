<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>UniGoa</title>
    <link href="<?php echo base_url('tempimport/css/bootstrap.min.css');?>" rel="stylesheet">
    <link href="<?php echo base_url('tempimport/css/simple-sidebar.css'); ?>" rel="stylesheet">
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
</head>
<body>
    <div id="wrapper">
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand">
                    <a href="#">
                        Start Bootstrap
                    </a>
                </li>
                <li>
                    <a href="http://localhost/uniGoa/index.php/site/loadBudgetMain">Budget</a>
                </li>
                <li>
                    <a href="http://localhost/uniGoa/index.php/site/loadSupplierMain">Supplier</a>
                </li>
                <li>
                    <a href="#">Mantainance</a>
                </li>
                <li>
                    <a href="http://localhost/uniGoa/index.php/site/loadPurchasesAdd">Purchases</a>
                </li>
                <li>
                    <a href="http://localhost/uniGoa/index.php/site/loadRoomMain">Room</a>
                </li>
                <li>
                    <a href="#">Category</a>
                </li>
                <li>
                    <?php echo form_open('http://localhost/uniGoa/index.php/f_login_controller/logout'); ?>
                    <input type='Submit' class="btn btn-default" value='Logout' />  
                    <?php echo form_close(); ?>
                </li>
            </ul>
        </div>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <a href="#menu-toggle" class="btn btn-default" id="menu-toggle">Menu</a>
                </div> 
            </div>
        </div>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h2>Insert Supplier Category</h2>
<?php echo form_open('site/addSuppliersCategory'); ?>
<div>
	<label for="lblName">Name</label>
	<input type="text" id="txtName" name="txtName" required="true"></input>
</div>
<div>
	<label for="lblRemark">Remark</label>
	<textarea id="txtarRemark" name="txtarRemark" ></textarea>
</div>

<div>
	<button>Submit</button>
</div>

<?php echo form_close(); ?>
</body>
</html>
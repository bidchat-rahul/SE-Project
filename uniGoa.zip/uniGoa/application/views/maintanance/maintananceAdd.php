<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h2>insert maintanance</h2>
<!--SerialNo :- autoIncrement
purchasesId :- inherit 
amcEndDate :- calculate add period -->
<?php echo form_open('site/test'); ?>
<div>
	<label for="lblAmcStartDate">AMC Start Date</label>
	<!--Date Picker dtpkrAmcStartDate -->
</div> 
<div>
	<label for="lblAmcEndDate">AMC End Date</label>
	<!--Date Picker dtpkrAmcEndDate -->

	<!--<label for="lblPeriod">For the Period Of </label>
	<input type="number" id="txtPeriod" name="txtPeriod"></input>
	<select name="sltPeriodType">
		<option>Month</option>
		<option>Year</option>
	</select> -->
</div>
<div>
	<label for="lblAmt">Amount</label>
	<input type="number" id="txtAmt" name="txtAmt" step="0.01"></input>
	<!-- get double datatype numbers -->
</div>
<div>
	<label for="lblBudgetHead">Budget Head</label>
	<select id="sltBudgetList_name" name="sltBudgetList_name">
		<option>a</option>
	</select>
</div>
<div>
	<label for="lblConditions">Any Conditions</label>
	<textarea id="txtarCondition" name="txtarCondition"></textarea> 
</div>
<div>
	<label for="lblRemark">Remark</label>
	<textarea id="txtarRemark" name="txtarRemark"></textarea>
</div>

<div>
	<button>Submit</button>
</div> 
<?php echo form_close(); ?>
</body>
</html>
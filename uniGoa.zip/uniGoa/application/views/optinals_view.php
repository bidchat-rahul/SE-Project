<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h2>Insert</h2>
<?php echo form_open('site/create'); ?> <!--updateRecord -->
<p>
	 <label for="id">Id:</label>
	 <input type="text" name="id" ></input>

</p>
<p>
	 <label for="title">Value:</label>
	 <input type="text" name="value" ></input>

</p>

<p>
	 <label for="content">date:</label>
	 <input type="text" name="date" ></input>	
</p>

<p>
	<button>Submit</button>

</p>

<?php echo form_close(); ?>
</body>
</html>
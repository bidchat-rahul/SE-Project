<!DOCTYPE html>
<html>
<head>
	
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/log.css');?>">
</head>
<body>
<div class="div1">
<h2>Budget</h2>

<div>
	<button style="color:blue">purchase_add</button>
	<button style="color:blue">Purchaseupdate_add</button>

</div>
</div>
<?php echo form_close(); ?>

</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h2>After purchasesAdd done</h2>
<?php echo form_open('site/test'); ?>
<div>
<!-- full table will be get displayed -->
	<label for="lblAdminBlockNo">Admin Block No Provied</label>
	<input type="text" id="txtAdminBlockNo" name="txtAdminBlockNo"></input>
</div>

<div>
	<button>Submit</button>
</div>
<?php echo form_close(); ?>

</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link href= <?php  echo base_url('importsFile/bootstrap/css/bootstrap.min.css') ?> rel="stylesheet"  type="text/css" >
    <link href=<?php  echo base_url('importsFile/bootstrap-datepicker/css/bootstrap-datepicker3.min.css') ?> rel="stylesheet"  type="text/css" >

	<script src=<?php echo base_url('importsFile/jquery/jquery-2.1.4.min.js') ?>></script>
	<script src=<?php echo base_url('importsFile/bootstrap/js/bootstrap.min.js') ?> ></script>
	<script src=<?php echo base_url('importsFile/bootstrap-datepicker/js/bootstrap-datepicker.min.js') ?>>
	</script>
</head>
<body>
<h2>Insert Purchases </h2>
<?php echo form_open('site/addPurchases'); ?>
<div>
	

	<div  id="form" class="form-horizontal"  >
	    <div class="form-body">
	        <div class="form-group">
	            <label for="lblDateOfPurchase" class="control-label col-md-3" >Date of Purchases</label>
	            <div class="col-md-3">
	                <input name="dtpkrDateOfPurchase" placeholder="yyyy-mm-dd" class="form-control datepicker" type="text">
	            </div>
	        </div>
	    </div>
	</div>  

<script type="text/javascript">

$(document).ready(function() {
    $('.datepicker').datepicker({
        autoclose: true,
        format: "yyyy-mm-dd",
        todayHighlight: true,
        orientation: "top left",
        todayBtn: true,
        todayHighlight: true,  
    });

});

</script> 


</div>

<div>
	<label for="lblItemBrand">Item Brand</label>
	<select id="sltCategory_name" name="sltCategory_name">
		
	<?php foreach ($category as $value) { ?>

		<option value="<?php echo $value->name ?>" ><?php echo $value->name ?></option>

	<?php
	} ?>

	</select>

</div>

<div>
	<label for="lblItemType">Item Type</label>
<!-- 	<select id="sltItems_name" name="sltItems_name">
	<?php// foreach ($item as $value) { ?>

		<option value="<?php //echo $value->name ?>" ><?php //echo $value->name ?></option>

	<?php
	//} ?>
	</select> -->

		<select id="sltItems_name" name="sltItems_name">
	<?php foreach ($item as $value) { ?>
		<option value="<?php echo $value->serialNo ?>" ><?php echo $value->name ?></option>

	<?php
	} ?>
	</select>
</div>

<div>
	<label for="lblDescOfItem">Desc Of Items</label>
	<textarea id="txtarDescOfItem" name="txtarDescOfItem"></textarea>
</div>

<div>
	<label for="lblWarrantyPeriod">Warenty period in months</label>
	<input type="number" id="txtWarrantyPeriod" name="txtWarrantyPeriod"></input>
</div>

<div>
	<label for="lblQty">Qty</label>
	<input type="number" id="txtQty" name="txtQty"></input>
</div>

<div>
	<label for="lblUnitPrice">per Unit Price</label>
	<input type="number" id="txtUnitPrice" name="txtUnitPrice" step="0.01"></input>
</div>

<div>
	<label for="lblTaxAmt">Tax Amt</label>
	<input type="number" id="txtTaxAmt" name="txtTaxAmt" step="0.01"></input>
	<!--total amt = (unitPrice*qty)+tax Amt -->
</div>

<div>
	<label for="lblSupplierId">Supplier name</label>
	<select id="sltSuppliers_name" name="sltSuppliers_name">
	<?php foreach ($supplier as $value) { ?>

		<option value="<?php echo $value->id ?>" ><?php echo $value->name ?></option>

	<?php
	} ?>
	</select>
</div>

<div>
	<label for="lblBudgetHead">Budget Head</label>
	<select id="sltBudgetList_name" name="sltBudetList_name">
	<?php foreach ($budget as $value) { ?>

		<option value="<?php echo $value->id ?>" ><?php echo $value->name ?></option>

	<?php
	} ?>
	</select>
</div>

<div>
	<label for="lblFileNo">File No</label>
	<input type="text" id="txtFileNo" name="txtFileNo"></input>
</div>

<div>
	<button>Submit</button>
</div>

<!--
filled afterwords initaily null
redirected to purchasesUpdateAdd.php
<div>
	<label for="lblAdminBlockNo">Admin Block No Provied</label>
	<input type="text" id="txtAdminBlockNo" name="txtAdminBlockNo"></input>
</div>
-->

<?php echo form_close(); ?>
</body>
</html>
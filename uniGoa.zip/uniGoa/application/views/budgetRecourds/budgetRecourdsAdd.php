<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h2>Insert budget - Recourds</h2>
<?php echo form_open('site/addBudgetRecords'); ?>
<div>
	<label for="lblYear">Year:</label>
	<input type="text" name="txtYear" id="txtYear" required="true"></input>
</div><div>
	<label for="lblAmt">Amount:</label>
	<input type="number" name="txtAmtProvided" id="txtAmtProvided" min="0" step="0.01" required="true"></input>
</div><div>
	<label for="lblBudgetHead">Budget Head:</label>
	<select name="sltBudgetListId" id="sltBudgetListId">
	<?php foreach ($budget as $value) { ?>

		<option value="<?php echo $value->id ?>" ><?php echo $value->name ?></option>

	<?php
	} ?>
	</select>
</div>
<div>
	<button>Submit</button>
</div>

<?php echo form_close(); ?>
</body>
</html>
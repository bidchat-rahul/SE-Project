<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h2>Insert budget</h2>
<?php echo form_open('site/addBugetList'); ?>
<div>
	 <label for="lblId">Head Number:</label>
	 <input type="text" name="txtId" id="txtId"></input>

</div>
<div>
	 <label for="lblName">Budget Head :</label>
	 <input type="text" name="txtName" id="txtName"></input>

</div>

<div>
	 <label for="lblDesc">Description:</label>
	 <textarea name="txtDesc" id="txtDesc"></textarea>	
</div>

<div>
	<button>Submit</button>

</div>

<?php echo form_close(); ?>

</body>
</html>
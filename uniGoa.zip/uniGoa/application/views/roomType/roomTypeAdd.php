<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h2>Insert RoomType</h2>
<?php echo form_open('site/addRoom'); ?>
<div>
	<label for="lblName">Name</label>
	<input type="text" name="txtName" id="txtName" required="true"></input>
</div>

<div>
	<label for="lblCapacity">Capacity</label>
	<input type="number" name="txtCapacity" id="txtCapacity" min="0" required="true"></input>
</div>

<div>
	<label for="lblDesc">Description</label>
	<textarea id="txtarDesc" name="txtarDesc" required="true"></textarea>
</div>

<div>
	<button>Submit</button>
</div>

<?php echo form_close(); ?>
</body>
</html>
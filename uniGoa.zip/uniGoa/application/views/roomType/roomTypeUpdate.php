<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<script type="text/javascript" src=<?php echo base_url('importsFile/jquery/jquery-2.1.4.min.js') ?>></script>

<h2>Update Room </h2>
<?php echo form_open('site/updateRoomData'); ?>
<div>
	<label for="cmbName">Name</label>
	<select name="sltName" id="sltName">
		<option value="">Please select a Room</option>
		<?php foreach($rooms->result() as $room){?>
		       <option value="<?php echo $room->id ?>"><?php echo $room->name; ?></option>
		   <?php } ?>
	</select>
</div>

<div>
	<label for="lblName">Name</label>
	<input type="text" name="txtName" id="txtName" value="" required="true"></input>
</div>

<div>
	<label for="lblCapacity">Capacity</label>
	<input type="number" name="txtCapacity" value="" id="txtCapacity" min="0" required="true"></input>
</div>

<div>
	<label for="lblDesc">Description</label>
	<textarea id="txtarDesc" name="txtarDesc" required="true"></textarea>
</div>

<div>
	<button>Submit</button>
</div>

<?php echo form_close(); ?>

<script type="text/javascript">
$("#sltName").change(function () {
	var id = $("#sltName").val();
	if (id!='') {
		$.ajax({
		    url : "<?php echo base_url('index.php/site/getDetails?id=') ?>" + id, 
		    type: "GET",
		    dataType: "JSON",
		    success: function(data)
		    {
		        $('[name="txtName"]').val(data.name);
		        $('[name="txtCapacity"]').val(data.capacity);
		        $('[name="txtarDesc"]').val(data.desc);
		    },
		    error: function (jqXHR, textStatus, errorThrown)
		    {
		        alert('Error get data from ajax');
		    }
		});
	};
});



</script>
</body>
</html>
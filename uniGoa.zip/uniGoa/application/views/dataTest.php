<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<p> <?php echo $myValue ?> </p>
<p> <?php echo $anotherValue ?> </p>

<p><?php 
foreach ($table as $value) { ?>
	<h2><?php echo anchor("site/deleteRow/$value->id",$value->value); ?></h2>
	<?php
	echo $value->id." ".$value->value." ".$value->Date ;
}  
?>
</p>
</body>
</html>